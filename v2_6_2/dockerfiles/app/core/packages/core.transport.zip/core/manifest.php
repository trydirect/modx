<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '639760c7bee0f6ef1b71ef57dbeb9dc8',
      'native_key' => 'core',
      'filename' => 'modNamespace/153e5651c862476e21629fc88c6cbbf1.vehicle',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modWorkspace',
      'guid' => '3660445e2b801865a5f60e65b685b8c9',
      'native_key' => 1,
      'filename' => 'modWorkspace/65aa6f1229ed6abd2adcff01defb6a41.vehicle',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modTransportProvider',
      'guid' => 'd599a66a592602210940ccfd45a5aa1d',
      'native_key' => 1,
      'filename' => 'modTransportProvider/77bbecfaf503daedd2b687af691cd9ce.vehicle',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '1d69ad4844e1ebf99231cbee739c28ca',
      'native_key' => 'topnav',
      'filename' => 'modMenu/112418656bd4c17f136e256da7d193c2.vehicle',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '7c9e09267dce65059d650f1293af22c0',
      'native_key' => 'usernav',
      'filename' => 'modMenu/931b4753a6dabbc1fd077d02a4b192c4.vehicle',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => 'f114e42389912f21d5565f8f2f78eeff',
      'native_key' => 1,
      'filename' => 'modContentType/3095e7414ad3ab377d955843fadd064e.vehicle',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '544a6f0bf93a4c44716e2125a9a1bc64',
      'native_key' => 2,
      'filename' => 'modContentType/d3ef2119ef056b7eb8bdf71badbe1d69.vehicle',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '1dbc2fe047bd1193ded8d5b37a0b5f4f',
      'native_key' => 3,
      'filename' => 'modContentType/c96d991a4cfc62eb45bb6da208c78be5.vehicle',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '3d5a92a6dfca9ce84ea928f87717d96a',
      'native_key' => 4,
      'filename' => 'modContentType/fd2fe8c8ac2d7a3a777c2b62fff1f7af.vehicle',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '8d2fb298341d89646f2c11923dd880f9',
      'native_key' => 5,
      'filename' => 'modContentType/550cf42eacc77446ba2b08368742b204.vehicle',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '096c8fcc1911a11fccc82944875d947a',
      'native_key' => 6,
      'filename' => 'modContentType/a3feddb525d4be585b897f29681a2991.vehicle',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '72df9e7c02547354cc32fffb3e21b549',
      'native_key' => 7,
      'filename' => 'modContentType/4690d64dc7149937a26d146d2cad3c7e.vehicle',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '9941aee8c7749c7ba88c32725dda8be0',
      'native_key' => 8,
      'filename' => 'modContentType/0ee035e6e74917d7c4da27fd9af7311b.vehicle',
    ),
    13 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '7b424e6afb77c07b7a267404f1189c04',
      'native_key' => NULL,
      'filename' => 'modClassMap/585b688c2d6079dce213d816cb5df6d9.vehicle',
    ),
    14 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '5e52608256fb9295678822fcac18158b',
      'native_key' => NULL,
      'filename' => 'modClassMap/8b7d54e9ce7d4bbbe69706d29dd8ce8e.vehicle',
    ),
    15 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '12e50794b812dc2ae32b0368b293afc7',
      'native_key' => NULL,
      'filename' => 'modClassMap/d7e254277befceb2f0375f14f1caee86.vehicle',
    ),
    16 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '250b74f0330e9fa31a530ecfdd23f6c4',
      'native_key' => NULL,
      'filename' => 'modClassMap/4b9c1bdaab0120fbb6b0b60d3793fe68.vehicle',
    ),
    17 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => 'bac98c8d66d228364ed866616540c176',
      'native_key' => NULL,
      'filename' => 'modClassMap/360513fda172d1a44e1115c1d074c6e2.vehicle',
    ),
    18 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => 'f5dc1c729449a3331b6b145268d06cca',
      'native_key' => NULL,
      'filename' => 'modClassMap/1c77b8741c6a35bcad12a57e0d750a98.vehicle',
    ),
    19 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '1c6c2fe949fbbd4e7999714b52104193',
      'native_key' => NULL,
      'filename' => 'modClassMap/d2efa46a9a6bc68d49e25d323a3a4082.vehicle',
    ),
    20 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => 'bddd1594ca9fc852c8d728285aea3dff',
      'native_key' => NULL,
      'filename' => 'modClassMap/030f1f55e616cbb85314d4cab635a24f.vehicle',
    ),
    21 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '437dd4b10bbee4c2d769d8478d930672',
      'native_key' => NULL,
      'filename' => 'modClassMap/b2107697b4eaf7a9a805075b80a74594.vehicle',
    ),
    22 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '97c7f4986caba606731d6c03b51b36aa',
      'native_key' => 'OnPluginEventBeforeSave',
      'filename' => 'modEvent/b662e1e5c72a78af16f945aa62b0b0d4.vehicle',
    ),
    23 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1d7692f8004b9ceae9999a93729e102e',
      'native_key' => 'OnPluginEventSave',
      'filename' => 'modEvent/e30dd1dbf7243a2f550a435a8427e815.vehicle',
    ),
    24 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'cb66c3182a0682c9403b258dd3c91723',
      'native_key' => 'OnPluginEventBeforeRemove',
      'filename' => 'modEvent/575d705a08e72affbb67bae7a12beb8e.vehicle',
    ),
    25 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c6cc732db31287411601121e11082512',
      'native_key' => 'OnPluginEventRemove',
      'filename' => 'modEvent/db477be7366d14157c4ff7e92f950248.vehicle',
    ),
    26 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8885f760c3d198f4f6e8c589fa2e1867',
      'native_key' => 'OnResourceGroupSave',
      'filename' => 'modEvent/6156737e6107aeb8f018c9ab3b7ccf09.vehicle',
    ),
    27 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '819289bbc1be1e61842cc8e75103e62a',
      'native_key' => 'OnResourceGroupBeforeSave',
      'filename' => 'modEvent/22a098e3acc4d761a5f4578e8d8c8db1.vehicle',
    ),
    28 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd7974e0ed98e708b65673f59ad9c96c0',
      'native_key' => 'OnResourceGroupRemove',
      'filename' => 'modEvent/1614fc6c408023cd5a306ade4d9fcd3d.vehicle',
    ),
    29 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '945236540995cf5971df734b04a1573c',
      'native_key' => 'OnResourceGroupBeforeRemove',
      'filename' => 'modEvent/f822e1c0fb1625aa2557c1b27d745bef.vehicle',
    ),
    30 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1f42478fc6592d74688d3001f38394ec',
      'native_key' => 'OnSnippetBeforeSave',
      'filename' => 'modEvent/518d4e44710347d11e6f99625a8c0a9c.vehicle',
    ),
    31 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '434f9af5e90a85bee3ae940205c6aa70',
      'native_key' => 'OnSnippetSave',
      'filename' => 'modEvent/b1b926830ddd296e80f4524d873ddacb.vehicle',
    ),
    32 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a0c16d07d3650bafb4fa8c01988aadf6',
      'native_key' => 'OnSnippetBeforeRemove',
      'filename' => 'modEvent/6503e0351543e1ffb450d8a010c4180d.vehicle',
    ),
    33 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1743dbb5ae0cf936f2d5c05bc0212789',
      'native_key' => 'OnSnippetRemove',
      'filename' => 'modEvent/5560898d390ce65dde064c2dd48d813d.vehicle',
    ),
    34 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4a5a6419e5ae90aa915ba5515de6b74d',
      'native_key' => 'OnSnipFormPrerender',
      'filename' => 'modEvent/908bb2631682d1f3b6e1f888f0ddb839.vehicle',
    ),
    35 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b113d2a6941963c0d696840318f6babd',
      'native_key' => 'OnSnipFormRender',
      'filename' => 'modEvent/bc4f09eb36f8a5790223d42aef93e7aa.vehicle',
    ),
    36 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '29e1a89b03ffca5f0aac1064df4db405',
      'native_key' => 'OnBeforeSnipFormSave',
      'filename' => 'modEvent/a522e37ace72b3467273d96acdc062cd.vehicle',
    ),
    37 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '399b3be7c710001ddd5530ad9f7ef1e0',
      'native_key' => 'OnSnipFormSave',
      'filename' => 'modEvent/5173a9f3a5034a4104be663ad2a8c401.vehicle',
    ),
    38 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a56d380d1d8b21120a97e48f4749d303',
      'native_key' => 'OnBeforeSnipFormDelete',
      'filename' => 'modEvent/438c1bd36930bf99be1f10e165fd47eb.vehicle',
    ),
    39 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'bfc94ea146d830121b7341a72abc627e',
      'native_key' => 'OnSnipFormDelete',
      'filename' => 'modEvent/f757a18859d26d0a108b87aa4304d24b.vehicle',
    ),
    40 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '88f3bcc174a300383b38ccd0fa7849eb',
      'native_key' => 'OnTemplateBeforeSave',
      'filename' => 'modEvent/d6e63fe69a0b9c2b6531879f9dbbc475.vehicle',
    ),
    41 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '73460116014870b2ec4559549c23cb97',
      'native_key' => 'OnTemplateSave',
      'filename' => 'modEvent/9c8719fa8a25196ec673f286832f4478.vehicle',
    ),
    42 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '674f6550e76dc9a47a271a83477dca9a',
      'native_key' => 'OnTemplateBeforeRemove',
      'filename' => 'modEvent/45e28151efdfc4636aa64eff73280a26.vehicle',
    ),
    43 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e85456b74e441071293a87c38b99392a',
      'native_key' => 'OnTemplateRemove',
      'filename' => 'modEvent/b749b47b5e22d9390aae9769e7c17497.vehicle',
    ),
    44 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a4ff1b35fb4a19b5233876c6a0066651',
      'native_key' => 'OnTempFormPrerender',
      'filename' => 'modEvent/837697bbe8f94ac0add375b56847916b.vehicle',
    ),
    45 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '046a01d4d6659131430befe9eae94b3a',
      'native_key' => 'OnTempFormRender',
      'filename' => 'modEvent/213c6367fd812335b611b2faaee6d72e.vehicle',
    ),
    46 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3f7810883576a10a02f2a43b0a0463a6',
      'native_key' => 'OnBeforeTempFormSave',
      'filename' => 'modEvent/59c6f76dc5ef5ccda5afc2fec6539762.vehicle',
    ),
    47 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f2445ec20867607c72976511f3d78b17',
      'native_key' => 'OnTempFormSave',
      'filename' => 'modEvent/097c9e46dba84315ba17ce798273089d.vehicle',
    ),
    48 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '843a9af21213a3939dbe3874951b4d2c',
      'native_key' => 'OnBeforeTempFormDelete',
      'filename' => 'modEvent/6861ff3f6ba17faaba81df4f1bc9f64e.vehicle',
    ),
    49 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0e85ca2eaac5710bfecb30e48656d86f',
      'native_key' => 'OnTempFormDelete',
      'filename' => 'modEvent/f2cbcca08f2514f6eeaba79cbed91d8b.vehicle',
    ),
    50 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3ccef826fe16698d0ea25ef9cb4704bd',
      'native_key' => 'OnTemplateVarBeforeSave',
      'filename' => 'modEvent/39fdaa8ed0c3049a78b975f541b6b467.vehicle',
    ),
    51 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0c815051d92e0816905576ef923ddfca',
      'native_key' => 'OnTemplateVarSave',
      'filename' => 'modEvent/d49545c86068e0c6105ebac23710d26f.vehicle',
    ),
    52 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a897cf23dd3f34f761d688b7a157b3b3',
      'native_key' => 'OnTemplateVarBeforeRemove',
      'filename' => 'modEvent/bf9d538c78b4983d43f967ca7bb4fd0a.vehicle',
    ),
    53 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd6d09f2f237ee37ab62bb37d1b32f89b',
      'native_key' => 'OnTemplateVarRemove',
      'filename' => 'modEvent/784a5d8a674520eff448b04e66ebe07d.vehicle',
    ),
    54 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b79eb6988d857911854a0c740492d558',
      'native_key' => 'OnTVFormPrerender',
      'filename' => 'modEvent/fe005fb447333889d5d7300a02c069ee.vehicle',
    ),
    55 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3c8c53bcfd032b151cc32ef709f01cae',
      'native_key' => 'OnTVFormRender',
      'filename' => 'modEvent/0a1de90f7be2544b18ea0deceefa0726.vehicle',
    ),
    56 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '85494edaa6b5920e92b62bfaa1ff9b62',
      'native_key' => 'OnBeforeTVFormSave',
      'filename' => 'modEvent/2eeaf96b7a2b27f3ae2700893bf9954a.vehicle',
    ),
    57 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3e18fac619527dfe18b21e9ee6c36145',
      'native_key' => 'OnTVFormSave',
      'filename' => 'modEvent/eabc18342d5fb1ec5d4f27ad5c3ce0ac.vehicle',
    ),
    58 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5aff7de52fd7cdc17720621085b7efd6',
      'native_key' => 'OnBeforeTVFormDelete',
      'filename' => 'modEvent/25efb29c0d8fbc3f525fe8517c8da70b.vehicle',
    ),
    59 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b82d5be2f9d60f0a33cfeb50ce58b60f',
      'native_key' => 'OnTVFormDelete',
      'filename' => 'modEvent/d83d09bed5a7b80cb231f0e1d6463855.vehicle',
    ),
    60 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ff864e5e3a2070df7f2792a7166f6702',
      'native_key' => 'OnTVInputRenderList',
      'filename' => 'modEvent/0051aab9466f40057d283e6fa3e84107.vehicle',
    ),
    61 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2bcb0493dcd99d7445d0bc844c0a014d',
      'native_key' => 'OnTVInputPropertiesList',
      'filename' => 'modEvent/33bfd7685b5a0e881baad64f3f728a9e.vehicle',
    ),
    62 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7334324721ae9e89124363f37d7da1b7',
      'native_key' => 'OnTVOutputRenderList',
      'filename' => 'modEvent/ae3c70cc341c65ab03d2ad7a75a49154.vehicle',
    ),
    63 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '21ef8a16df754571fec8a85d476b4441',
      'native_key' => 'OnTVOutputRenderPropertiesList',
      'filename' => 'modEvent/5289e7ccc18e0b43405d3f1ce2894d0d.vehicle',
    ),
    64 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4a4e291e7a6505a7e14a7b7d2bad3822',
      'native_key' => 'OnUserGroupBeforeSave',
      'filename' => 'modEvent/32b2ef6875ece9d5069f6c12bc60eee0.vehicle',
    ),
    65 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '32beb03c6ee70f5525808f9aaf0725e7',
      'native_key' => 'OnUserGroupSave',
      'filename' => 'modEvent/8ea1d199a07d56dcc051a371d81565fc.vehicle',
    ),
    66 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3a21633f29b2cf5ef71047ff416972c8',
      'native_key' => 'OnUserGroupBeforeRemove',
      'filename' => 'modEvent/b883c4ef19f2be375c47ec1f3039900c.vehicle',
    ),
    67 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'dc4803e470316ad8060e87f74a5428e2',
      'native_key' => 'OnUserGroupRemove',
      'filename' => 'modEvent/2012df4d0f7ca8a6fa221e293792523b.vehicle',
    ),
    68 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '02dc2a6bdb64ec9d9500e8b4a0e01652',
      'native_key' => 'OnBeforeUserGroupFormSave',
      'filename' => 'modEvent/9a6a18a7ae50aaf45c05093e2552f989.vehicle',
    ),
    69 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b01713321946e0aadf2840eb4f29fcaa',
      'native_key' => 'OnUserGroupFormSave',
      'filename' => 'modEvent/b64592f90064259a36a188adc18b6593.vehicle',
    ),
    70 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e30f1c57f0b4ecf02f0d1ab2ef377562',
      'native_key' => 'OnBeforeUserGroupFormRemove',
      'filename' => 'modEvent/c14fcc54e99fcb5ad21a0a4f59abff17.vehicle',
    ),
    71 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e70fc5ce2385c06c41fa949711da7abe',
      'native_key' => 'OnBeforeUserGroupFormRemove',
      'filename' => 'modEvent/23f6f01398d8202fb733a45a0bc8ab60.vehicle',
    ),
    72 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ead528f247bd2862c06e64a5ea99ed88',
      'native_key' => 'OnUserProfileBeforeSave',
      'filename' => 'modEvent/ff1209adf066d20afeb5ade3ce526833.vehicle',
    ),
    73 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '970d7500cfee327d48e1431bca088575',
      'native_key' => 'OnUserProfileSave',
      'filename' => 'modEvent/5d2ec40a384cfee83b04215a733d8dd4.vehicle',
    ),
    74 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b21a9572d8e24a7832395470e4f5b2f6',
      'native_key' => 'OnUserProfileBeforeRemove',
      'filename' => 'modEvent/71669befd335f7b548aef20886781177.vehicle',
    ),
    75 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '20f6a4e5a3e7b9c0923869ffb9a654fd',
      'native_key' => 'OnUserProfileRemove',
      'filename' => 'modEvent/5ae1e8cb7131cbd98f1b0c1ea72ff5fd.vehicle',
    ),
    76 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a4ad8b8079de6d8ae9a4c1143d0f174b',
      'native_key' => 'OnDocFormPrerender',
      'filename' => 'modEvent/38b02048a0bf7e08025e0c9e675a8892.vehicle',
    ),
    77 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd1c7a3b5fc6b20ca421c867af418f51c',
      'native_key' => 'OnDocFormRender',
      'filename' => 'modEvent/13208c1cea0fd876e2fd98f0f0630251.vehicle',
    ),
    78 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '70349e4f0db711393314b92f446911d3',
      'native_key' => 'OnBeforeDocFormSave',
      'filename' => 'modEvent/c3038da35842e6a981922526c6fd4f55.vehicle',
    ),
    79 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd62b21184d33b6a47d9977deca1f0619',
      'native_key' => 'OnDocFormSave',
      'filename' => 'modEvent/8282d1568873ab85b488417af0a62451.vehicle',
    ),
    80 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a939dc79609050cd9aff851bfe486b24',
      'native_key' => 'OnBeforeDocFormDelete',
      'filename' => 'modEvent/245b536e0d34749721eb0384d5cd9f1b.vehicle',
    ),
    81 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '224c0849d1628ad92ec1ded7430a44f4',
      'native_key' => 'OnDocFormDelete',
      'filename' => 'modEvent/f2543b99d49111ba1a26b44c0dca778d.vehicle',
    ),
    82 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'daf41fc8aaa7ed9198a095880cc16570',
      'native_key' => 'OnDocPublished',
      'filename' => 'modEvent/ae6c82999f55aa3079055a1de571e462.vehicle',
    ),
    83 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2ac233874a27c2f25f2ed72beecf3d59',
      'native_key' => 'OnDocUnPublished',
      'filename' => 'modEvent/0e5aac47ce3d2f2168c316ebce0eecd3.vehicle',
    ),
    84 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '01e77331138a8f6828826f94a6f2ef1d',
      'native_key' => 'OnBeforeEmptyTrash',
      'filename' => 'modEvent/80f85a306f4004f3278dc1779f9ff771.vehicle',
    ),
    85 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'aef3ef361d539ef60ecbac18b4269c30',
      'native_key' => 'OnEmptyTrash',
      'filename' => 'modEvent/3288908ca69929217253ed9b1e4c4fb9.vehicle',
    ),
    86 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f72dc872b60fa62e6a1460f7948ef20e',
      'native_key' => 'OnResourceTVFormPrerender',
      'filename' => 'modEvent/30549209957f0809628c7ec3be10a71b.vehicle',
    ),
    87 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '72be38767bc9d837c840c59b1936e067',
      'native_key' => 'OnResourceTVFormRender',
      'filename' => 'modEvent/fbdf473ec7373ca803b873c7c14613be.vehicle',
    ),
    88 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '818a5d23494f01eddd2e419ecfa7b799',
      'native_key' => 'OnResourceAutoPublish',
      'filename' => 'modEvent/526f47fa46dab58e8344f73ad8f031e7.vehicle',
    ),
    89 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8840ff473e08f6b9ecd4e38ca0df98b7',
      'native_key' => 'OnResourceDelete',
      'filename' => 'modEvent/04397afb4f41395b802418b857028451.vehicle',
    ),
    90 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd8d9823065c5783335fa5454ec628a61',
      'native_key' => 'OnResourceUndelete',
      'filename' => 'modEvent/94b5187bde32dbb40fa331b029fc1261.vehicle',
    ),
    91 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f5400e02da82be8f70e495ebdbab2151',
      'native_key' => 'OnResourceBeforeSort',
      'filename' => 'modEvent/5919ece15a3c85600c25b4f9174b9ada.vehicle',
    ),
    92 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1bbbb35531dbd199d9f42a042e8405d9',
      'native_key' => 'OnResourceSort',
      'filename' => 'modEvent/baf559493b307917d21f6694c19be7fa.vehicle',
    ),
    93 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '25e02850fd809f5e3d332232a3cd6c06',
      'native_key' => 'OnResourceDuplicate',
      'filename' => 'modEvent/f2dbb2f6281388b3e11f47d2b4157cb9.vehicle',
    ),
    94 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b41f9dbb5624cf0e0a059cd18b4fd6e1',
      'native_key' => 'OnResourceToolbarLoad',
      'filename' => 'modEvent/c0602dde690d0f56ca2c3b0b9d8e7d6e.vehicle',
    ),
    95 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4b1801ba40bea331afc7b90550e61270',
      'native_key' => 'OnResourceRemoveFromResourceGroup',
      'filename' => 'modEvent/e5963f28a32e4b09170295dfe07ec623.vehicle',
    ),
    96 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd0fd414b1e201809b5af20eefa6e46ed',
      'native_key' => 'OnResourceAddToResourceGroup',
      'filename' => 'modEvent/79a46b5a3c3b9f68a269189d25297693.vehicle',
    ),
    97 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f6e5953a9db4caee53bbccf139e1c11a',
      'native_key' => 'OnResourceCacheUpdate',
      'filename' => 'modEvent/049fb73f6e97b6505a4ff3c3248c5ea9.vehicle',
    ),
    98 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'afb8405f088d968f671c8fb54046e8cb',
      'native_key' => 'OnRichTextEditorRegister',
      'filename' => 'modEvent/596a7551b24a21a41d1faf0c699f4424.vehicle',
    ),
    99 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '309cc97dfade5aa1db4ffb429056bf80',
      'native_key' => 'OnRichTextEditorInit',
      'filename' => 'modEvent/c23a767551ff04e3ebd848c432638a25.vehicle',
    ),
    100 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'fda70a2825f65d1b5f506c116073f94a',
      'native_key' => 'OnRichTextBrowserInit',
      'filename' => 'modEvent/30d39ffb78fdd5dc55c4c86bf5bf6dd0.vehicle',
    ),
    101 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '908c3d1fad0ba89f0f2439311f80ef0d',
      'native_key' => 'OnWebLogin',
      'filename' => 'modEvent/38212265571b7865e352f22703cfd29d.vehicle',
    ),
    102 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '279bbf5ad57ffac9f0fadd97ee2dedd9',
      'native_key' => 'OnBeforeWebLogout',
      'filename' => 'modEvent/21b0ae0a75d8598aef74c93de1fe15b2.vehicle',
    ),
    103 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c0129b3e7d60587dc91c83c6336f5c1a',
      'native_key' => 'OnWebLogout',
      'filename' => 'modEvent/8d99aa3e7075cba06920d4167a5cce3e.vehicle',
    ),
    104 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c75dad65b9b2d9bb5e1cdcedb22b0a38',
      'native_key' => 'OnManagerLogin',
      'filename' => 'modEvent/63ad58002151dc873649dd9b1ead8a32.vehicle',
    ),
    105 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '56612866de00fd65f07e66bb402471ad',
      'native_key' => 'OnBeforeManagerLogout',
      'filename' => 'modEvent/83e5ac24e74285a33e314e8f007276ca.vehicle',
    ),
    106 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2b6592321f07d3c4664a407f7b6d0f27',
      'native_key' => 'OnManagerLogout',
      'filename' => 'modEvent/cc49b251f7ad84ddfab4f5a670d6ff49.vehicle',
    ),
    107 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1529530ff522eab4602da22f072ba41b',
      'native_key' => 'OnBeforeWebLogin',
      'filename' => 'modEvent/24bbf8b80ca055d5232998a854aff37e.vehicle',
    ),
    108 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '57410aa71896ca3bd8259a9d49cdbfc7',
      'native_key' => 'OnWebAuthentication',
      'filename' => 'modEvent/3d35753d9b083cb37c9ce902c8f23e7c.vehicle',
    ),
    109 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5560a40321eb26641306b9e4aec6e9de',
      'native_key' => 'OnBeforeManagerLogin',
      'filename' => 'modEvent/9c92bf7a0c8a1cf6c8bdf1796842f8b8.vehicle',
    ),
    110 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b13c6c3c8b759e138ed32c50e943f63a',
      'native_key' => 'OnManagerAuthentication',
      'filename' => 'modEvent/73f0d9267d897294f1ef07df2d9c2a94.vehicle',
    ),
    111 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ce4fe7e55510f83bce7dee4d401e9108',
      'native_key' => 'OnManagerLoginFormRender',
      'filename' => 'modEvent/5e46b7384ad40a70ee6a24c33b1a5a51.vehicle',
    ),
    112 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '88911aae0043ee567fc3d80b0fa5dcec',
      'native_key' => 'OnManagerLoginFormPrerender',
      'filename' => 'modEvent/2c751216d37546ae3f24dc63492e9afb.vehicle',
    ),
    113 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9a93635fae6af039858211704ab44af8',
      'native_key' => 'OnPageUnauthorized',
      'filename' => 'modEvent/9ec4ab799abb18d7f1dd5b51da89084d.vehicle',
    ),
    114 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '63e5d0354d3d4288e15c73dee7740771',
      'native_key' => 'OnUserFormPrerender',
      'filename' => 'modEvent/2283051d0d35130c144217073549790a.vehicle',
    ),
    115 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4fe922168cde8da15043b5cbdc143d55',
      'native_key' => 'OnUserFormRender',
      'filename' => 'modEvent/b3e77ae947ccdb442ca8c6d7885062d1.vehicle',
    ),
    116 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2994def922e7d7d26042bed9caa5788f',
      'native_key' => 'OnBeforeUserFormSave',
      'filename' => 'modEvent/d57bad910331382e6f7c7ca87b35f96b.vehicle',
    ),
    117 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '15c735efc4c3470c0f5fb16c60424b7e',
      'native_key' => 'OnUserFormSave',
      'filename' => 'modEvent/0ed8a27f1d065d7ecdfd39cbc65484e6.vehicle',
    ),
    118 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e2ffad83afe83f226ad995c2e125b2ac',
      'native_key' => 'OnBeforeUserFormDelete',
      'filename' => 'modEvent/846361b7b0787aa44bba6455a50f53f0.vehicle',
    ),
    119 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3c81d0d9493dd32ba78280fd998492fc',
      'native_key' => 'OnUserFormDelete',
      'filename' => 'modEvent/31cf0e1d489837074d9c5a58a5090f40.vehicle',
    ),
    120 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'df7f3e2a02da0469a01ba8fb798594aa',
      'native_key' => 'OnUserNotFound',
      'filename' => 'modEvent/e30fc702b7811019a3ca4cab7eac93de.vehicle',
    ),
    121 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd48ab18594627d40af670160a2a9eb3f',
      'native_key' => 'OnBeforeUserActivate',
      'filename' => 'modEvent/165b7dafbd57f19b4147eb9d27b6905d.vehicle',
    ),
    122 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'fa2958c1512bd819d8919848fe68d60e',
      'native_key' => 'OnUserActivate',
      'filename' => 'modEvent/85a9d5501b4bfabb6e4580e260b80731.vehicle',
    ),
    123 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5038b264dfc775a3d1eafcc287823c7d',
      'native_key' => 'OnBeforeUserDeactivate',
      'filename' => 'modEvent/98bb3e2c588d187f3df17e168d4ed114.vehicle',
    ),
    124 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e868e4c85959a29cc4dfcadd77320c26',
      'native_key' => 'OnUserDeactivate',
      'filename' => 'modEvent/403b4c08d0e4e7854e64e8cde23ba71b.vehicle',
    ),
    125 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '174bd512127b83880c306e5d07baddd6',
      'native_key' => 'OnBeforeUserDuplicate',
      'filename' => 'modEvent/bcf295ffea0386001d88c922a9e466c4.vehicle',
    ),
    126 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5991198ae3dfde245d4601445741259a',
      'native_key' => 'OnUserDuplicate',
      'filename' => 'modEvent/2b20e96df6e096f5eec7729ed3eb651f.vehicle',
    ),
    127 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '07b2358ad3201e426297397d1780fef3',
      'native_key' => 'OnUserChangePassword',
      'filename' => 'modEvent/c66afa5cdf9ccccab984f784d0e3b62f.vehicle',
    ),
    128 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd93eb4022ca5bdc67ff82edb31745600',
      'native_key' => 'OnUserBeforeRemove',
      'filename' => 'modEvent/494942d06619edc5dc9b6a6ff03cbf7a.vehicle',
    ),
    129 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2fe31ad76799bfa1c24fc8e43fb1506e',
      'native_key' => 'OnUserBeforeSave',
      'filename' => 'modEvent/36841522c7ef8792b030e08d9fd20f0d.vehicle',
    ),
    130 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5dd6f6175f390607735ee6bb192cb7eb',
      'native_key' => 'OnUserSave',
      'filename' => 'modEvent/df1dbb259486e8403c962e40e18bfd5d.vehicle',
    ),
    131 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f895da2c3197d9ee13076091a082831c',
      'native_key' => 'OnUserRemove',
      'filename' => 'modEvent/cee221cbc6e2f23243c99dcabc34f844.vehicle',
    ),
    132 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '76301c993c1d642381f4d2a4336a460d',
      'native_key' => 'OnUserBeforeAddToGroup',
      'filename' => 'modEvent/2f6935f500fccb14a72951e4c318e6e4.vehicle',
    ),
    133 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2db92451385ca422b3f73535d6307084',
      'native_key' => 'OnUserAddToGroup',
      'filename' => 'modEvent/d4fc66e495b0c31735e318fbe7b8d5bf.vehicle',
    ),
    134 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '07b8388f2fc5252308b6394254084013',
      'native_key' => 'OnUserBeforeRemoveFromGroup',
      'filename' => 'modEvent/2683f2e3e8c36dbc91081944b07e4d55.vehicle',
    ),
    135 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd54105e54a48bc9f7dc225897cdb32bc',
      'native_key' => 'OnUserRemoveFromGroup',
      'filename' => 'modEvent/db6b497fd5700a88d8a3742200aecaae.vehicle',
    ),
    136 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '74d62fa10ae909d0e1e437938f25a0f9',
      'native_key' => 'OnWebPagePrerender',
      'filename' => 'modEvent/f32e94739445f0ed2a625e21531c51c4.vehicle',
    ),
    137 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4ab826ff58ef8ee89252c61dd17c852e',
      'native_key' => 'OnBeforeCacheUpdate',
      'filename' => 'modEvent/cd8ef9f4a9795df6c81431a8242640d1.vehicle',
    ),
    138 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '42e1d42b1546b0ff6691208062ea56fc',
      'native_key' => 'OnCacheUpdate',
      'filename' => 'modEvent/6888435aafdb8736246bf6c0c2da4d5d.vehicle',
    ),
    139 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '48e67b2d801b603aa884e27b802d9d39',
      'native_key' => 'OnLoadWebPageCache',
      'filename' => 'modEvent/f7129752a1005be610b5493146284132.vehicle',
    ),
    140 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '277664b69247724ebca8ebed0e2a4a6a',
      'native_key' => 'OnBeforeSaveWebPageCache',
      'filename' => 'modEvent/5a0222b3189f3e0042afc9647e86193e.vehicle',
    ),
    141 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7a5eca3aeb700b865bfb1d6eb1973394',
      'native_key' => 'OnSiteRefresh',
      'filename' => 'modEvent/7dacf838ddf4f36313b46a9923926e33.vehicle',
    ),
    142 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ee110b474c29a278ab3101b36fea7730',
      'native_key' => 'OnFileManagerDirCreate',
      'filename' => 'modEvent/0184c0acdf1901f17765451264720be7.vehicle',
    ),
    143 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5d23c0dfb570dff6870ac1e1b7134088',
      'native_key' => 'OnFileManagerDirRemove',
      'filename' => 'modEvent/0306c9c25139758112e42ef42b0839bf.vehicle',
    ),
    144 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '805bc51489a137fd867f7d2f83ca544f',
      'native_key' => 'OnFileManagerDirRename',
      'filename' => 'modEvent/72eee7cc4de2752cd179a2e59b40802d.vehicle',
    ),
    145 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '600d319d4b61c76cb8f4bb76fee73465',
      'native_key' => 'OnFileManagerFileRename',
      'filename' => 'modEvent/54289715ef8708e6eb97f1519520f204.vehicle',
    ),
    146 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'fdf02b1dd99277fce63044b2d3c5e87a',
      'native_key' => 'OnFileManagerFileRemove',
      'filename' => 'modEvent/e32fac92666c7c8803259fa7316b2cfa.vehicle',
    ),
    147 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '97f11e01e1dfc2b78edefd91d0fd8514',
      'native_key' => 'OnFileManagerFileUpdate',
      'filename' => 'modEvent/8146d11011760ab2f22f60758c5d1ad3.vehicle',
    ),
    148 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '45d5e7c8b2f6f5a0fda8ef98503dfa81',
      'native_key' => 'OnFileManagerFileCreate',
      'filename' => 'modEvent/0e78472c1b54eba4a94876f8aa0a309a.vehicle',
    ),
    149 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f2b5b03d1cddc9666e44244474aac080',
      'native_key' => 'OnFileManagerBeforeUpload',
      'filename' => 'modEvent/d3fa823a005696f884de10abc18764a0.vehicle',
    ),
    150 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '34cfa408daecf93339c015eb51e5feac',
      'native_key' => 'OnFileManagerUpload',
      'filename' => 'modEvent/9170d3aa874c39bc32ea20e34af17552.vehicle',
    ),
    151 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '49aec058a8899515d6e39a3d9e255882',
      'native_key' => 'OnFileManagerMoveObject',
      'filename' => 'modEvent/53d5b47949c020b4d21d5e5f1e31d705.vehicle',
    ),
    152 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '985f3e3bdf027c3e0d25bf32ca18ad91',
      'native_key' => 'OnFileCreateFormPrerender',
      'filename' => 'modEvent/b5046ddee62644b0ab9689bbf1820581.vehicle',
    ),
    153 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4908864cedf9d485938814c0c62ffee6',
      'native_key' => 'OnFileEditFormPrerender',
      'filename' => 'modEvent/b8545091e00d9b498f458744805607d9.vehicle',
    ),
    154 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ebfca6ae24a00677d2ec9adc1fa761e1',
      'native_key' => 'OnManagerPageInit',
      'filename' => 'modEvent/82bfbf501d19d13d54c65e46b0a4fe36.vehicle',
    ),
    155 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '861d66fcaa7b210664de543da8583d19',
      'native_key' => 'OnManagerPageBeforeRender',
      'filename' => 'modEvent/728bf6d50a23a024e63184459f168fad.vehicle',
    ),
    156 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '96823270903794a963c495a658324c91',
      'native_key' => 'OnManagerPageAfterRender',
      'filename' => 'modEvent/e7feec8c27afd3987e5358f5cf304005.vehicle',
    ),
    157 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'fd1f08ab8136f2eb89621aed03625292',
      'native_key' => 'OnWebPageInit',
      'filename' => 'modEvent/0e28b54a84aec472448fe1ef59ba1279.vehicle',
    ),
    158 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f3084c4f3f7592565198eaea7296bd12',
      'native_key' => 'OnLoadWebDocument',
      'filename' => 'modEvent/8858c46e908b12217ae192a54b281fe5.vehicle',
    ),
    159 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'bb2211dd4d0072cc2d11c294ebd40c0c',
      'native_key' => 'OnParseDocument',
      'filename' => 'modEvent/3203c9afc3a5d0692b833152aa9c07a2.vehicle',
    ),
    160 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e7a3b9e0e10db9f96c7a13e11409bab5',
      'native_key' => 'OnWebPageComplete',
      'filename' => 'modEvent/baca0f630b4c04a3e7af6011bbe90ac1.vehicle',
    ),
    161 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9e11fc0f14f4dd87d346b6198b2e1a4a',
      'native_key' => 'OnBeforeManagerPageInit',
      'filename' => 'modEvent/f77331150e24ab889c9d8d07ab71f5cb.vehicle',
    ),
    162 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2c7173e3bd5c4c80e01c8740b4a4e016',
      'native_key' => 'OnPageNotFound',
      'filename' => 'modEvent/d418af93c5a90a93de967098e50b5396.vehicle',
    ),
    163 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ef79b4be53be34209d403358ef1bf04c',
      'native_key' => 'OnHandleRequest',
      'filename' => 'modEvent/b2af57fa07be13be5c99e19208d3b3de.vehicle',
    ),
    164 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9dd03513a4e33d28c57c942db3f3485f',
      'native_key' => 'OnMODXInit',
      'filename' => 'modEvent/6289c3d075cbceddc8a42e1e289a9736.vehicle',
    ),
    165 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'aaa5f6b879b40dab63b3aa98e4f94189',
      'native_key' => 'OnElementNotFound',
      'filename' => 'modEvent/de9bc2ef40b343338c24cb83ca781589.vehicle',
    ),
    166 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9245aa0daaf0dd37aff5973876e34f3d',
      'native_key' => 'OnSiteSettingsRender',
      'filename' => 'modEvent/87ce0be695aa5b41f688ef16668e8943.vehicle',
    ),
    167 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2ccbc023c411f13d863860090e3a071a',
      'native_key' => 'OnInitCulture',
      'filename' => 'modEvent/1fbbb6a79ffc48c72ef6f9a8071dd310.vehicle',
    ),
    168 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0ec8be781df85cdd6d147dc522c885dc',
      'native_key' => 'OnCategorySave',
      'filename' => 'modEvent/89f601745b4dbf17f183557e540aab72.vehicle',
    ),
    169 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e7080544e3445c15a3dcf23ef0818576',
      'native_key' => 'OnCategoryBeforeSave',
      'filename' => 'modEvent/a33d3541cb60262451e35ed2ce19397a.vehicle',
    ),
    170 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '25f3f1f89252eb2fe88e37e475432593',
      'native_key' => 'OnCategoryRemove',
      'filename' => 'modEvent/9856c80f8ec621de71372e5ad07b4cbe.vehicle',
    ),
    171 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd1e5961cf08cd350c5d17e3d6150f553',
      'native_key' => 'OnCategoryBeforeRemove',
      'filename' => 'modEvent/83c3b80253f297faab2605f221c187d2.vehicle',
    ),
    172 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3bbdd94210c8eb6f0011a5b863c47166',
      'native_key' => 'OnChunkSave',
      'filename' => 'modEvent/de42e7d87410bb632426574b7ab9eb14.vehicle',
    ),
    173 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '85ae7e9a3312a2f77a2b52c5ec086322',
      'native_key' => 'OnChunkBeforeSave',
      'filename' => 'modEvent/3067a6ebe2abd54ff088b21a4b900e6d.vehicle',
    ),
    174 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6b96f856d6844a75c0b58a2a4c6bfd68',
      'native_key' => 'OnChunkRemove',
      'filename' => 'modEvent/e6fe7f78f93d1b5d9ff934af6d7589fa.vehicle',
    ),
    175 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e5bd75e6847b19c3fd1eaeb11f6a1063',
      'native_key' => 'OnChunkBeforeRemove',
      'filename' => 'modEvent/7a1fc68ec253a1a4e1b703267306d710.vehicle',
    ),
    176 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ad91e954cfe09de6b42e25ca3ffc75ac',
      'native_key' => 'OnChunkFormPrerender',
      'filename' => 'modEvent/59f298056cd79da0e77473aed54143bb.vehicle',
    ),
    177 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b7fa2d74acdda8f0e203d96892db7cd7',
      'native_key' => 'OnChunkFormRender',
      'filename' => 'modEvent/2f112996f53366fbd1333f3ab1c0057f.vehicle',
    ),
    178 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '72a73a72e2dc966047e8adbe17807668',
      'native_key' => 'OnBeforeChunkFormSave',
      'filename' => 'modEvent/fe1c03f89d21bf3e7ed0a0dbdc7a68d9.vehicle',
    ),
    179 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ffcdfaf2fe33dd891d20b7144eb26f5e',
      'native_key' => 'OnChunkFormSave',
      'filename' => 'modEvent/cf6332709308d24c73ac62adcbd3573d.vehicle',
    ),
    180 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '46f1278ecb73565935d8b17934b2f89f',
      'native_key' => 'OnBeforeChunkFormDelete',
      'filename' => 'modEvent/6e771934f5de3f3f182be9cc0acf499d.vehicle',
    ),
    181 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5b53d44007f1ea2770efe8f199a4735e',
      'native_key' => 'OnChunkFormDelete',
      'filename' => 'modEvent/8e95d5d5478d7c0412b19d5f26f35713.vehicle',
    ),
    182 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f62d6502151fe823bf50a79601663f97',
      'native_key' => 'OnContextSave',
      'filename' => 'modEvent/e8567c61cad7cecb9f5a867a51b685af.vehicle',
    ),
    183 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ee0120274db2e303b50ce0d1e5e67994',
      'native_key' => 'OnContextBeforeSave',
      'filename' => 'modEvent/d19f7edeba6cc9157a50b5ef5c238698.vehicle',
    ),
    184 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e9b560bfa194721f85c7682d460101bb',
      'native_key' => 'OnContextRemove',
      'filename' => 'modEvent/3ee39f581093b7ee6de8a334e3fc581d.vehicle',
    ),
    185 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4fdc433e08f09c262058a4d6ebe5b3d2',
      'native_key' => 'OnContextBeforeRemove',
      'filename' => 'modEvent/c78cb3f7c01ebe5882585c12762afb6d.vehicle',
    ),
    186 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3add20754d37d9b90eedfe28fe92372b',
      'native_key' => 'OnContextFormPrerender',
      'filename' => 'modEvent/84ece482e9243561de804b4c767cd89b.vehicle',
    ),
    187 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7188f53134fe49ec57096190d1bbad39',
      'native_key' => 'OnContextFormRender',
      'filename' => 'modEvent/10e4531fd6d265e962fb4590a88d9c83.vehicle',
    ),
    188 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6c8ddf563ff683515486f3ade1f3801f',
      'native_key' => 'OnPluginSave',
      'filename' => 'modEvent/b1162ced403c34dba136da25fc1dd4ee.vehicle',
    ),
    189 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4e665eae06a8828f8f0b7a90ab8bf046',
      'native_key' => 'OnPluginBeforeSave',
      'filename' => 'modEvent/ba000a627587f3c1f0d5328432413f77.vehicle',
    ),
    190 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'dac39167a45c015cc829ac60dd072b13',
      'native_key' => 'OnPluginRemove',
      'filename' => 'modEvent/d799e8216ffae026b499f25e582eec6e.vehicle',
    ),
    191 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3b7de7367763af643ad4e28bfc8b9a8e',
      'native_key' => 'OnPluginBeforeRemove',
      'filename' => 'modEvent/001da25b37e7f345fabbcab15737c39a.vehicle',
    ),
    192 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6bda3e87f1ca2075cac301a9a73c62d2',
      'native_key' => 'OnPluginFormPrerender',
      'filename' => 'modEvent/eae8a83449bc4f867471c0b3de11084f.vehicle',
    ),
    193 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8d3423ea57f4b1c1dd47f92f9a89ba43',
      'native_key' => 'OnPluginFormRender',
      'filename' => 'modEvent/b11da4b98621c83ea521f1623703fa49.vehicle',
    ),
    194 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ae6f4969fee568c31956f89a8afbb24a',
      'native_key' => 'OnBeforePluginFormSave',
      'filename' => 'modEvent/eba940ccc207e0f28d259362b44b934c.vehicle',
    ),
    195 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '396ee56c2f2e8f559716115ca82aee5e',
      'native_key' => 'OnPluginFormSave',
      'filename' => 'modEvent/74fc75de4cd4fa81000ec9bc960eef1a.vehicle',
    ),
    196 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '845c5b6cea7ad856708f1391f5348be3',
      'native_key' => 'OnBeforePluginFormDelete',
      'filename' => 'modEvent/1bfff2aaa12f3aa06aa593bfd538fac0.vehicle',
    ),
    197 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd944c2bc4aaa0a6cfe346c3de998c531',
      'native_key' => 'OnPluginFormDelete',
      'filename' => 'modEvent/7d3e734fd774454570c00d1264148706.vehicle',
    ),
    198 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '409fc3b73a08274b06b33ebd35042f77',
      'native_key' => 'OnPropertySetSave',
      'filename' => 'modEvent/a9d623862f2f988ffe1a3f906ede1e1f.vehicle',
    ),
    199 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '006f4d1716b9dbdfdd76a443096ab6b6',
      'native_key' => 'OnPropertySetBeforeSave',
      'filename' => 'modEvent/e083699abeda9a78383645205bb2f609.vehicle',
    ),
    200 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'fcc7e8f0518f07f1bda460e269c83fb3',
      'native_key' => 'OnPropertySetRemove',
      'filename' => 'modEvent/3f4ebafd389b3f95d10d5a47251df496.vehicle',
    ),
    201 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7a9ed1c7a0d10e3007b9da4335305a9c',
      'native_key' => 'OnPropertySetBeforeRemove',
      'filename' => 'modEvent/00ba5c60ebca4c0a6a15f7150ef81f81.vehicle',
    ),
    202 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b28c838daf1f2823b38ffe7d0508c426',
      'native_key' => 'OnMediaSourceBeforeFormDelete',
      'filename' => 'modEvent/00fb10838f1d63c01959b87692fea19c.vehicle',
    ),
    203 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd5abe22c0d4624ac0b1ae54b2b679bc7',
      'native_key' => 'OnMediaSourceBeforeFormSave',
      'filename' => 'modEvent/d527beb634ebeb5b4a5dbbe81ba4ebd0.vehicle',
    ),
    204 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3ad464133367d32c39663b67486d59f7',
      'native_key' => 'OnMediaSourceGetProperties',
      'filename' => 'modEvent/3a36c9f4c3869ce609d2e17eafa6f1ae.vehicle',
    ),
    205 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0a073c0dc83e8b34799e81cc3ea4a307',
      'native_key' => 'OnMediaSourceFormDelete',
      'filename' => 'modEvent/d704ef8ed8a3feff54235cbd29075729.vehicle',
    ),
    206 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '72bbd903a0272cb83cf08c0e1150f992',
      'native_key' => 'OnMediaSourceFormSave',
      'filename' => 'modEvent/4cb1bafbbfd339faf57470e1f9d2db81.vehicle',
    ),
    207 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '569e60387d85fb0c48fb2fef24d63dc1',
      'native_key' => 'OnMediaSourceDuplicate',
      'filename' => 'modEvent/d21ba91e93cad6f07e890ff27382901b.vehicle',
    ),
    208 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a3e10e2a20f706f339d068701e2d61ec',
      'native_key' => 'OnPackageInstall',
      'filename' => 'modEvent/46d75755592ee2e54c8aee0aab1bbdd7.vehicle',
    ),
    209 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '786366b251c2dd02f3df3aac957202d7',
      'native_key' => 'OnPackageUninstall',
      'filename' => 'modEvent/c7d3685596909d09f3a237e237b8048d.vehicle',
    ),
    210 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f926e2888e63cc9922704c1ca28df9c1',
      'native_key' => 'OnPackageRemove',
      'filename' => 'modEvent/858ef04b967ee4d25ac9157652ef3fc2.vehicle',
    ),
    211 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd3d713511a235868f455b6902d3b4752',
      'native_key' => 'access_category_enabled',
      'filename' => 'modSystemSetting/33846954075fcf2e18f404c573d4e766.vehicle',
    ),
    212 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '60708b9ebc717aaa380b0aa0701e1431',
      'native_key' => 'access_context_enabled',
      'filename' => 'modSystemSetting/29d22890864dfb5f56faec5e15393266.vehicle',
    ),
    213 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e0c44b8dc3bb8d7e70f7dbfe15abbd57',
      'native_key' => 'access_resource_group_enabled',
      'filename' => 'modSystemSetting/6d45131e911c011854a5902f77270deb.vehicle',
    ),
    214 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b211de86f0a3e103aa05a2d4afd2e3fa',
      'native_key' => 'allow_forward_across_contexts',
      'filename' => 'modSystemSetting/f03497f22d8ea865bae6efeb6d941546.vehicle',
    ),
    215 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b584857cb92849a1aaec614802ddfefd',
      'native_key' => 'allow_manager_login_forgot_password',
      'filename' => 'modSystemSetting/bdf93c7bf8c1f54416651b14275ba13f.vehicle',
    ),
    216 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd4dcfb361aea82a0f6c265d91ae4a82e',
      'native_key' => 'allow_multiple_emails',
      'filename' => 'modSystemSetting/f5c2edcb1fb75993582cc4ea40192094.vehicle',
    ),
    217 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c0d6c39769e29f439db6620de11abfcf',
      'native_key' => 'allow_tags_in_post',
      'filename' => 'modSystemSetting/1dce30b2327ac6664d376a63e4cc0b6b.vehicle',
    ),
    218 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0fb63105b683d5482f9810b808f237ff',
      'native_key' => 'archive_with',
      'filename' => 'modSystemSetting/fa49847e9a291d06f5b6ef3661bc3b93.vehicle',
    ),
    219 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '09028176010a0d78583170a2400125e1',
      'native_key' => 'auto_menuindex',
      'filename' => 'modSystemSetting/6f13edcd3f7f7f966aef7c61a5e97af3.vehicle',
    ),
    220 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bfae12eb0d01582dde1a75746c9eee54',
      'native_key' => 'auto_check_pkg_updates',
      'filename' => 'modSystemSetting/d287c12702b39e534387ebbc051032f4.vehicle',
    ),
    221 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8e653f4ff0b85f5a9b3fd7f654788b5a',
      'native_key' => 'auto_check_pkg_updates_cache_expire',
      'filename' => 'modSystemSetting/7a48dc65c9dec706597642e1dfba2d3b.vehicle',
    ),
    222 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4f6343c4a31337019635313db8b03325',
      'native_key' => 'automatic_alias',
      'filename' => 'modSystemSetting/44430c80b231764e2e1590c5d774ed5c.vehicle',
    ),
    223 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7e5825274be17888b825411316278675',
      'native_key' => 'base_help_url',
      'filename' => 'modSystemSetting/8f11ac63ee6c87b0d1260ab0284561d7.vehicle',
    ),
    224 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '166f9468eeed9c342b7301983ebfe75f',
      'native_key' => 'blocked_minutes',
      'filename' => 'modSystemSetting/602d61660a78bf2dc1920c67b92ff146.vehicle',
    ),
    225 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '39c1601f984e83589cbb654bc8bbaa78',
      'native_key' => 'cache_action_map',
      'filename' => 'modSystemSetting/fbe81636ca0cbe7e23916de90872de8d.vehicle',
    ),
    226 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2face7bfe0d3f1b9a7a8d2491edb837e',
      'native_key' => 'cache_alias_map',
      'filename' => 'modSystemSetting/9d762455261bf220abef6ee987253dc3.vehicle',
    ),
    227 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'adec16082931fc5101f02d86875243b3',
      'native_key' => 'use_context_resource_table',
      'filename' => 'modSystemSetting/77e6b9245a8240bab8ae5265442ec770.vehicle',
    ),
    228 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '37dcd0276d04425526929f85784ba9a5',
      'native_key' => 'cache_context_settings',
      'filename' => 'modSystemSetting/990a8238dc92496052f25364a6eb604d.vehicle',
    ),
    229 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7119fad209c02e78d35bde11d73ab571',
      'native_key' => 'cache_db',
      'filename' => 'modSystemSetting/3286b6b13e389a06126ec4300c6619f3.vehicle',
    ),
    230 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '163564a43cff5677188a12e0f07ddf06',
      'native_key' => 'cache_db_expires',
      'filename' => 'modSystemSetting/03f87751416178e923904a557130acbd.vehicle',
    ),
    231 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '848e1d28b116aee405b03af3c464aa4a',
      'native_key' => 'cache_db_session',
      'filename' => 'modSystemSetting/c15572d6cddfb76b52f54e9a8c6997e8.vehicle',
    ),
    232 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fbdb21c118bc806d76a5b058723e03f6',
      'native_key' => 'cache_db_session_lifetime',
      'filename' => 'modSystemSetting/d13067cdf76dbe742413332334184cbd.vehicle',
    ),
    233 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b9325ef2c85e14a0f103db8debe54e4b',
      'native_key' => 'cache_default',
      'filename' => 'modSystemSetting/59dfb0c6f5f00559de0a727a4bbfe34e.vehicle',
    ),
    234 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cb39a510264d69eafa75584688568e8b',
      'native_key' => 'cache_disabled',
      'filename' => 'modSystemSetting/b32d825ba004a69634215fc937f1de9a.vehicle',
    ),
    235 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'de44ce071b279d6e37807b2d08013380',
      'native_key' => 'cache_expires',
      'filename' => 'modSystemSetting/0401ac8653b538ad8e673e133d03042f.vehicle',
    ),
    236 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8be02de6f5d6ab199c9c355a65e0f8b8',
      'native_key' => 'cache_format',
      'filename' => 'modSystemSetting/65fcc2e6a614540b5d5da636cd1b2c6b.vehicle',
    ),
    237 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd9032bd7eb141636909d08f4d8a0d134',
      'native_key' => 'cache_handler',
      'filename' => 'modSystemSetting/61da79c046dbc9a0b8827f4385c29ec5.vehicle',
    ),
    238 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6514b6fd57d327d2d99b4bbd51a0dc16',
      'native_key' => 'cache_lang_js',
      'filename' => 'modSystemSetting/bf7c0dee948bce71413957b9111ab28b.vehicle',
    ),
    239 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b58531c0283bd648ae9e957ca16d3957',
      'native_key' => 'cache_lexicon_topics',
      'filename' => 'modSystemSetting/b6405d455909283fae1d8393fe93fc71.vehicle',
    ),
    240 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '28cd72c303bd064c0bcbc2338860219c',
      'native_key' => 'cache_noncore_lexicon_topics',
      'filename' => 'modSystemSetting/73d5a4a879dc29cc39e4ecc7727d2549.vehicle',
    ),
    241 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '993704fcea20aa285bc875f5550b62df',
      'native_key' => 'cache_resource',
      'filename' => 'modSystemSetting/8402a6924c335d3f1c44ada9c24f9dcf.vehicle',
    ),
    242 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3aaacfc4a1df30a3285d011eeb37f315',
      'native_key' => 'cache_resource_expires',
      'filename' => 'modSystemSetting/3eb026443f08159c95702c471cece8a8.vehicle',
    ),
    243 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '857037529672715b092b15fe91b9f5ab',
      'native_key' => 'cache_scripts',
      'filename' => 'modSystemSetting/fc20180a11c07c98e3ff44b573b967d3.vehicle',
    ),
    244 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f67b3aae139d8221b644c7caf74afbc9',
      'native_key' => 'cache_system_settings',
      'filename' => 'modSystemSetting/7ed8e5949b7b7add9e7f26f67c0ab417.vehicle',
    ),
    245 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd67f61b600ce77b5bba7b93670b3a9a6',
      'native_key' => 'clear_cache_refresh_trees',
      'filename' => 'modSystemSetting/9a22f12c90a4ef6f1ed781323c508421.vehicle',
    ),
    246 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '890eb0ea42e8a1225428cff4d630610a',
      'native_key' => 'compress_css',
      'filename' => 'modSystemSetting/40660e73c392e9e8dd18be37271612d7.vehicle',
    ),
    247 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ef3b3de97f9b689e1a4d731eca2d8067',
      'native_key' => 'compress_js',
      'filename' => 'modSystemSetting/f3263bd6e8e48084812f7c4933f4288c.vehicle',
    ),
    248 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a85dd46f09d60cebf7f754cad773b2ac',
      'native_key' => 'compress_js_max_files',
      'filename' => 'modSystemSetting/bd052a0b15d521444fa0dd254059c869.vehicle',
    ),
    249 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '26eb7dfe694f801bab19fbf46e4ca91e',
      'native_key' => 'confirm_navigation',
      'filename' => 'modSystemSetting/e5cf1ea485734e875e0f1be4dc5d156b.vehicle',
    ),
    250 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cfba1e992c4832ab5770924513278bc0',
      'native_key' => 'container_suffix',
      'filename' => 'modSystemSetting/84aa335e928a23a1d89bf54f7b712d35.vehicle',
    ),
    251 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e7ed06e40421bfd9511b14424e211d78',
      'native_key' => 'context_tree_sort',
      'filename' => 'modSystemSetting/4ac1f39ad84f8c28c93b76dcde279418.vehicle',
    ),
    252 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bba0e84912ef9a929db3cbe569497ee9',
      'native_key' => 'context_tree_sortby',
      'filename' => 'modSystemSetting/02aabbf17d2c73ccdd6f62bb8ab08884.vehicle',
    ),
    253 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '17a4e7ec1f16c81e8a493fa02ba46f41',
      'native_key' => 'context_tree_sortdir',
      'filename' => 'modSystemSetting/099097554d3da86e29661c4ed0e60aaa.vehicle',
    ),
    254 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '43f4f7bf5775c040fd6e98dd1798d629',
      'native_key' => 'cultureKey',
      'filename' => 'modSystemSetting/64f6f6e339472647feac061cbbfbc1e2.vehicle',
    ),
    255 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '92ac25002cf168d54cce8baa2793cd85',
      'native_key' => 'date_timezone',
      'filename' => 'modSystemSetting/4888eac34d4d8c7a05f33aeb63c36e5d.vehicle',
    ),
    256 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '919d92f21c09006d219c6edc562be07d',
      'native_key' => 'debug',
      'filename' => 'modSystemSetting/0b66737208774a54bc82229ca5a45b52.vehicle',
    ),
    257 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1ebcfd5f48b34d7999b374fd74910a39',
      'native_key' => 'default_duplicate_publish_option',
      'filename' => 'modSystemSetting/eccc01b1790ba42e15d669592859944b.vehicle',
    ),
    258 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '675201cddb8e2d79de6c3ca35811e2a0',
      'native_key' => 'default_media_source',
      'filename' => 'modSystemSetting/e8e6e0b0dc82201e43a80b71f1ca086c.vehicle',
    ),
    259 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '133c275a715e9fda2868ef17ce9bc6f1',
      'native_key' => 'default_per_page',
      'filename' => 'modSystemSetting/ce83ac395d128e011c6fc019eef0a2f4.vehicle',
    ),
    260 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '44d49dafeffd9d463e70de0175bad769',
      'native_key' => 'default_context',
      'filename' => 'modSystemSetting/dadc5b2c0f666cb682bcb9254b720e93.vehicle',
    ),
    261 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '78ba50a27f8bc740f3ce70373dae198b',
      'native_key' => 'default_template',
      'filename' => 'modSystemSetting/2c2efca61854ec88932ef89ab67cfdd8.vehicle',
    ),
    262 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '571ba0699dc430ac3f9c792a6850149a',
      'native_key' => 'default_content_type',
      'filename' => 'modSystemSetting/c11636bcd2b6aa4fd2dca6e88fda5d49.vehicle',
    ),
    263 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '88f1b73a26ecbbc99be6fbbd5fb4bf54',
      'native_key' => 'editor_css_path',
      'filename' => 'modSystemSetting/323724d1fa16de3e53bd85dbf76e9731.vehicle',
    ),
    264 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6a34450a522afacf4e368fb1d789abb1',
      'native_key' => 'editor_css_selectors',
      'filename' => 'modSystemSetting/c27a21848d8deffda97350b11c044b16.vehicle',
    ),
    265 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '045790f333cae1a8133d7f423845603b',
      'native_key' => 'emailsender',
      'filename' => 'modSystemSetting/065fc9fba0ea41f2c8e698bbfbb826b3.vehicle',
    ),
    266 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a53321048f31d83bc5b36bd76a69275e',
      'native_key' => 'emailsubject',
      'filename' => 'modSystemSetting/9d426feb6cf65dee890017db42ca715c.vehicle',
    ),
    267 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bf4c8735d016b7e087ece20ec744eccd',
      'native_key' => 'enable_dragdrop',
      'filename' => 'modSystemSetting/a552b3f6fcc5ea743295be61ead1b538.vehicle',
    ),
    268 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2c72186f68da9802d1ca5eed57ed78e8',
      'native_key' => 'error_page',
      'filename' => 'modSystemSetting/40fba0a35216f550e332acbf63516652.vehicle',
    ),
    269 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4d33eac024d481d2abd025572352c0b7',
      'native_key' => 'failed_login_attempts',
      'filename' => 'modSystemSetting/2928746f88a00617d39b0f061f8c10ba.vehicle',
    ),
    270 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c98d1cc0f142fd55b1bfa5f4ecb87f5a',
      'native_key' => 'fe_editor_lang',
      'filename' => 'modSystemSetting/52b3e46d9a3acd9e8f5fd1120b9e8e17.vehicle',
    ),
    271 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e6fc8458b1b99d95eb81cdfa1dd1260b',
      'native_key' => 'feed_modx_news',
      'filename' => 'modSystemSetting/54f3793b76d561ee4b24b9c00dc35c28.vehicle',
    ),
    272 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c0d792638ab1bd09f8c3ccce1406b3a5',
      'native_key' => 'feed_modx_news_enabled',
      'filename' => 'modSystemSetting/fb5b0ac2ca5bfda86146f52e6a0f648c.vehicle',
    ),
    273 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6e23e8f233c67ce2fecc31b8e22fb669',
      'native_key' => 'feed_modx_security',
      'filename' => 'modSystemSetting/ffc234faa4f502234320f7c0cb9f7fc9.vehicle',
    ),
    274 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '986c81224d798331b8526483dbf1d618',
      'native_key' => 'feed_modx_security_enabled',
      'filename' => 'modSystemSetting/ea617980e76ae9b8472f8782e0fe7bd7.vehicle',
    ),
    275 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c4b1f21cdb7e4c560a0daa82ae98a01f',
      'native_key' => 'filemanager_path',
      'filename' => 'modSystemSetting/e8a35d6554a54a735a8f556fbaaa3126.vehicle',
    ),
    276 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7233f308999ebeb27a59b66f98995da2',
      'native_key' => 'filemanager_path_relative',
      'filename' => 'modSystemSetting/d05bf203af07282bcad387d4ea869821.vehicle',
    ),
    277 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fe792b3295cf056d420221adff9ed9ca',
      'native_key' => 'filemanager_url',
      'filename' => 'modSystemSetting/a51d684a529dc851b13279eeb106f2c7.vehicle',
    ),
    278 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '87556edcf5a3f37255303353f058771a',
      'native_key' => 'filemanager_url_relative',
      'filename' => 'modSystemSetting/b6826c9799ca06306e3932d1005d2d05.vehicle',
    ),
    279 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f127bb3972a5a53113e05eba1ba6db44',
      'native_key' => 'forgot_login_email',
      'filename' => 'modSystemSetting/27ba495f6d3854255415a63abf28489d.vehicle',
    ),
    280 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ee3ab3434e77d391844d04c4eaec6f61',
      'native_key' => 'form_customization_use_all_groups',
      'filename' => 'modSystemSetting/d014f502603540e0296b4e0c38c55076.vehicle',
    ),
    281 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '56447b641445a0a672261fe15d5c24b6',
      'native_key' => 'forward_merge_excludes',
      'filename' => 'modSystemSetting/965d6dd80d594f4be65ab6f9e5f4fdf6.vehicle',
    ),
    282 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b4ce01d23279609bdd80910a282aced6',
      'native_key' => 'friendly_alias_lowercase_only',
      'filename' => 'modSystemSetting/ce75398d8f26909629c3b0548b49fc9d.vehicle',
    ),
    283 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '99301c1df7b74c82e2691c760df16c32',
      'native_key' => 'friendly_alias_max_length',
      'filename' => 'modSystemSetting/012a9a8029b14b5dc7a060e7cd589219.vehicle',
    ),
    284 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ec6c724c5dd31f395689bb32df2888ad',
      'native_key' => 'friendly_alias_realtime',
      'filename' => 'modSystemSetting/44968179c4793cbb05420d6559f53105.vehicle',
    ),
    285 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '76e3a5225134705c2f1982f816cf1d88',
      'native_key' => 'friendly_alias_restrict_chars',
      'filename' => 'modSystemSetting/ecb548992fc60c4aeb26a89ff36c3c0d.vehicle',
    ),
    286 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '433823d4887f591599c3bdc6c92e3c48',
      'native_key' => 'friendly_alias_restrict_chars_pattern',
      'filename' => 'modSystemSetting/1bcf8ae9863912a2474fe94e26cfc146.vehicle',
    ),
    287 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '72659257f893fccb5a26aaa749340784',
      'native_key' => 'friendly_alias_strip_element_tags',
      'filename' => 'modSystemSetting/e997a1e20444809894ad817dc7320cea.vehicle',
    ),
    288 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '486e1e96b2d9e705fb363db8beee52f0',
      'native_key' => 'friendly_alias_translit',
      'filename' => 'modSystemSetting/57aa7b86e9d6dcee1fa6ddcb0ce38991.vehicle',
    ),
    289 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '67e06fb451af3deec6475dc40bfe60d8',
      'native_key' => 'friendly_alias_translit_class',
      'filename' => 'modSystemSetting/fe8e96d84aba95745e4b23970cd66a44.vehicle',
    ),
    290 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5ca9cdc2406846444294ac575a6e30fc',
      'native_key' => 'friendly_alias_translit_class_path',
      'filename' => 'modSystemSetting/d63aab5ff32232b9ccea6b233711f850.vehicle',
    ),
    291 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '860e35c50ad6c31e85847be03638ea08',
      'native_key' => 'friendly_alias_trim_chars',
      'filename' => 'modSystemSetting/146d5dee1b4af0ae49bb534b9c557bf2.vehicle',
    ),
    292 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a131746cb0606c662eca77d4547cd669',
      'native_key' => 'friendly_alias_word_delimiter',
      'filename' => 'modSystemSetting/aa913e97f1c419586c01298771f73b59.vehicle',
    ),
    293 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '91b1eb6e0a3602e3e74dfd1aa853b795',
      'native_key' => 'friendly_alias_word_delimiters',
      'filename' => 'modSystemSetting/003f36046e0155d362a5fc621d00a0ac.vehicle',
    ),
    294 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '369f0cd82b75e9e5105c359f6ad1d191',
      'native_key' => 'friendly_urls',
      'filename' => 'modSystemSetting/710d1b7f4138dbc5885155f0b2eafc3e.vehicle',
    ),
    295 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b66882e652dd434beb7f38e27b44b898',
      'native_key' => 'friendly_urls_strict',
      'filename' => 'modSystemSetting/a2f64c3acd33bce16371291adc0fe3bb.vehicle',
    ),
    296 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b592e89a2aa679e5420b22e96beae1d4',
      'native_key' => 'use_frozen_parent_uris',
      'filename' => 'modSystemSetting/0c2d8156a8e2274f935b837c80590761.vehicle',
    ),
    297 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7772e2c112114e62bf41e57f99ed86aa',
      'native_key' => 'global_duplicate_uri_check',
      'filename' => 'modSystemSetting/2c9af26785f134bcf54b18a4289e9628.vehicle',
    ),
    298 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '04a376c663197fb0cd8a731c31a82582',
      'native_key' => 'hidemenu_default',
      'filename' => 'modSystemSetting/40c57b861135bf09af407c3c4d339534.vehicle',
    ),
    299 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '889941f3663ec2ae77ab3f4f6c1d612b',
      'native_key' => 'inline_help',
      'filename' => 'modSystemSetting/b65a96ed42aaeeb522bd5080463d88db.vehicle',
    ),
    300 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c167442a737b288f32008529fbe58a56',
      'native_key' => 'locale',
      'filename' => 'modSystemSetting/8804661504bbb5068b3e7d602942c15e.vehicle',
    ),
    301 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd1037d64c2867f32cc06904da0622c41',
      'native_key' => 'log_level',
      'filename' => 'modSystemSetting/46a2f44bc73cbdc67ea1fcb814d9115d.vehicle',
    ),
    302 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1429dff69478feaf92c8cf1cc4718855',
      'native_key' => 'log_target',
      'filename' => 'modSystemSetting/2e7b32533ffa5a93a5d41db4f126981c.vehicle',
    ),
    303 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5a60c227889d2d226ab3aad9076a6373',
      'native_key' => 'link_tag_scheme',
      'filename' => 'modSystemSetting/3d980869420d3eb233364e0b38a3897e.vehicle',
    ),
    304 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd7beb291a579de1d0aa719f1f712913e',
      'native_key' => 'lock_ttl',
      'filename' => 'modSystemSetting/984d3437f8fea83db2eafd8984a8407e.vehicle',
    ),
    305 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'adaa68b77eba86777f9a74a4fd8e994c',
      'native_key' => 'mail_charset',
      'filename' => 'modSystemSetting/abdef4f3f0ca38257a6c037843b060c2.vehicle',
    ),
    306 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '82502b12ffbc9510cd38ec8d0099b76b',
      'native_key' => 'mail_encoding',
      'filename' => 'modSystemSetting/ea0c50ec95721e836347e22a55cb7596.vehicle',
    ),
    307 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1529d903b6c1c2dd23149e7b228545ce',
      'native_key' => 'mail_use_smtp',
      'filename' => 'modSystemSetting/476bf1f43a989a28678cb2929d178c3e.vehicle',
    ),
    308 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4b7e86ce83952d6b7a2e79e09d8616ba',
      'native_key' => 'mail_smtp_auth',
      'filename' => 'modSystemSetting/a9eb090edfc5bcb9acbea271490df65d.vehicle',
    ),
    309 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9c868730afc026dcd6868ce916574a2b',
      'native_key' => 'mail_smtp_helo',
      'filename' => 'modSystemSetting/77ba65ffb2badec9ed446e6d820d2bcd.vehicle',
    ),
    310 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2f3e41a316a841c5499adeef135b8c4d',
      'native_key' => 'mail_smtp_hosts',
      'filename' => 'modSystemSetting/aca372a3f9ae2d689dd1ea0d4edbe208.vehicle',
    ),
    311 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'be1fe4f443cf80f2d5dc9aae379ee0ab',
      'native_key' => 'mail_smtp_keepalive',
      'filename' => 'modSystemSetting/f632d9c1ac058fa21f20c8871b275673.vehicle',
    ),
    312 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4b80a4709819870a2bdeb985e9f30935',
      'native_key' => 'mail_smtp_pass',
      'filename' => 'modSystemSetting/7f29d8ddea5c5f3013617f059b430757.vehicle',
    ),
    313 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bb90488e57ff49855354cc0154c5b0e0',
      'native_key' => 'mail_smtp_port',
      'filename' => 'modSystemSetting/7f32169734f28409366e448000cccbd2.vehicle',
    ),
    314 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c2cea37c6d3a423ae685d226745bfb04',
      'native_key' => 'mail_smtp_prefix',
      'filename' => 'modSystemSetting/0acb117b1e40a2f040e0dbcb40bb7c44.vehicle',
    ),
    315 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '752b3bc33855e4c5c91d3dc35d849c5d',
      'native_key' => 'mail_smtp_single_to',
      'filename' => 'modSystemSetting/202891ec280108a3f1e4269c58e5172a.vehicle',
    ),
    316 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9ff80069c3de26266a3139b23e397605',
      'native_key' => 'mail_smtp_timeout',
      'filename' => 'modSystemSetting/9f776539eba5e7b5010cc9ece6d0019f.vehicle',
    ),
    317 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '09fdd150e6a4e329953b85b384eb6ae1',
      'native_key' => 'mail_smtp_user',
      'filename' => 'modSystemSetting/8e43babc402385155a32ee2f2fb8ca3d.vehicle',
    ),
    318 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '08744e224014c124eeb1e4c41f080178',
      'native_key' => 'manager_date_format',
      'filename' => 'modSystemSetting/a9aa8c775bfc576446dc3d4bb05d83da.vehicle',
    ),
    319 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7c93f56e7f1f46a30dacb88cacee2750',
      'native_key' => 'manager_favicon_url',
      'filename' => 'modSystemSetting/a6cf0a8777305478863d0107ff070128.vehicle',
    ),
    320 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '37b4faf1fb2dbb4669803e8607497412',
      'native_key' => 'manager_js_cache_file_locking',
      'filename' => 'modSystemSetting/9af60598c4b5def6546f42a711c0ee53.vehicle',
    ),
    321 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e5caae0aeb9a954b53a861e45a73cb25',
      'native_key' => 'manager_js_cache_max_age',
      'filename' => 'modSystemSetting/6c1701f2b036ea198b8404f6a80f7a5a.vehicle',
    ),
    322 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8235ae60a4a471a1ca21b58442eae0d2',
      'native_key' => 'manager_js_document_root',
      'filename' => 'modSystemSetting/2d2c1cd9e83fb0f17e243450134dd47d.vehicle',
    ),
    323 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '040311fdb1548cd174ba17c9c453508a',
      'native_key' => 'manager_js_zlib_output_compression',
      'filename' => 'modSystemSetting/4ff8e67b80a131aa9070f0c15ec10bdc.vehicle',
    ),
    324 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a3df2f7b3ce55bd3c80b7602fda9c076',
      'native_key' => 'manager_time_format',
      'filename' => 'modSystemSetting/b82bc5b842e683587bf80125c452a6d1.vehicle',
    ),
    325 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '35968bf8d602d642d79f09d39a7c6970',
      'native_key' => 'manager_direction',
      'filename' => 'modSystemSetting/e008045c64bdd5ad745cfe0a8da4e7da.vehicle',
    ),
    326 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4c09b563f8218cef85210027b682467c',
      'native_key' => 'manager_lang_attribute',
      'filename' => 'modSystemSetting/65f411b69e996e355c1b174b58d8feb1.vehicle',
    ),
    327 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a11e26dca35e3d210dd73029dfbef3ce',
      'native_key' => 'manager_language',
      'filename' => 'modSystemSetting/8ce508315907f3f381f19312e691f722.vehicle',
    ),
    328 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '36446096cb2445b7ddc95f34fcefc1e2',
      'native_key' => 'manager_login_url_alternate',
      'filename' => 'modSystemSetting/5032cc776fbdc5b212dd86268e1f3ea3.vehicle',
    ),
    329 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4de673fd9ee89bbc82891ad1309b0f16',
      'native_key' => 'manager_theme',
      'filename' => 'modSystemSetting/d7c07c31dc03d8c25ed30f623007eeb3.vehicle',
    ),
    330 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '10a589debcd8e3927c495a26733e2c27',
      'native_key' => 'manager_week_start',
      'filename' => 'modSystemSetting/deaf52bb3d1db1de09052612bc896ab9.vehicle',
    ),
    331 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cdcbdefdb6e052f0725d406ab8acbdb2',
      'native_key' => 'modx_browser_tree_hide_files',
      'filename' => 'modSystemSetting/0149d9639af806ff5a2ca733d61bc2b4.vehicle',
    ),
    332 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e30b0d7a6ac6b049c247516a14e650ec',
      'native_key' => 'modx_browser_tree_hide_tooltips',
      'filename' => 'modSystemSetting/9b48565d767f288432da535ef120cef5.vehicle',
    ),
    333 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '441b3f8deb47fd78c4b39e9a004fd60e',
      'native_key' => 'modx_browser_default_sort',
      'filename' => 'modSystemSetting/8eed229361f17d4c119736aaa4e415f6.vehicle',
    ),
    334 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ccd676c810c58fef8a453fb7bc581be3',
      'native_key' => 'modx_browser_default_viewmode',
      'filename' => 'modSystemSetting/fb05ac441fb7fb9e3f4e9bed8fe924d2.vehicle',
    ),
    335 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a60f95168f8f16f3976d324c938fcaf7',
      'native_key' => 'modx_charset',
      'filename' => 'modSystemSetting/08d01c18efae227e420e551dd1b4c5c8.vehicle',
    ),
    336 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9a04278a83fa4aea345ed2acf61f3d00',
      'native_key' => 'principal_targets',
      'filename' => 'modSystemSetting/e179a4329c9ff173958f6a9fe2985dae.vehicle',
    ),
    337 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5bf6b3ee6ae6c782dabfca82179ae5ae',
      'native_key' => 'proxy_auth_type',
      'filename' => 'modSystemSetting/fa453d9c927007384f7dcd7c9008b5ec.vehicle',
    ),
    338 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '18988d1bb9d972b6cbef8d677978c620',
      'native_key' => 'proxy_host',
      'filename' => 'modSystemSetting/778696f69f66a1928e78bedfb63924fc.vehicle',
    ),
    339 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '18a5cd1d4256bb5ab548a5ab5a3c2321',
      'native_key' => 'proxy_password',
      'filename' => 'modSystemSetting/e2dcb1ebed335ca014501353eeb5c3da.vehicle',
    ),
    340 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e0229d6ce80de5ff928827c9e85da3cd',
      'native_key' => 'proxy_port',
      'filename' => 'modSystemSetting/adb9b4621849a47145115139be42cefa.vehicle',
    ),
    341 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fb5d6d9e561391145bbe12123552b781',
      'native_key' => 'proxy_username',
      'filename' => 'modSystemSetting/2eaa8c39a5feed1bf440d50fb4f130e1.vehicle',
    ),
    342 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2985bcec4dcc37a12921a4e5bde389a1',
      'native_key' => 'password_generated_length',
      'filename' => 'modSystemSetting/704602191c25013f6b068c3cea500263.vehicle',
    ),
    343 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '37c8ab961ac7f3de22a8e62106022c54',
      'native_key' => 'password_min_length',
      'filename' => 'modSystemSetting/9c14d3503ba8b3732fe006840908eb87.vehicle',
    ),
    344 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ddebd7def35ce88922150a9c610b16ee',
      'native_key' => 'phpthumb_allow_src_above_docroot',
      'filename' => 'modSystemSetting/57036bf0449dee0222b9e72ca8d8ad5e.vehicle',
    ),
    345 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '02e36939f26511eabda870f02b87c646',
      'native_key' => 'phpthumb_cache_maxage',
      'filename' => 'modSystemSetting/c77c1e83072f1ca41c074021ddf494e9.vehicle',
    ),
    346 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '43387b754e49ed2909f18b764bb710be',
      'native_key' => 'phpthumb_cache_maxsize',
      'filename' => 'modSystemSetting/9b1a43461a59bb35d14c2854b6d63990.vehicle',
    ),
    347 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0e024ca31e5154e8284e38f694f192fd',
      'native_key' => 'phpthumb_cache_maxfiles',
      'filename' => 'modSystemSetting/198b3921031413fbf228cdbab114326d.vehicle',
    ),
    348 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a4e7c04798383e0b60828826fabca812',
      'native_key' => 'phpthumb_cache_source_enabled',
      'filename' => 'modSystemSetting/543ff4ce379dd95c2b5c88c22a1fa956.vehicle',
    ),
    349 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '598c35d015f4e2984dd17031511330b7',
      'native_key' => 'phpthumb_document_root',
      'filename' => 'modSystemSetting/ed03b14122289733a93f7b2555a513ff.vehicle',
    ),
    350 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd0ad0fb6438627d5aed5239b990c8a5e',
      'native_key' => 'phpthumb_error_bgcolor',
      'filename' => 'modSystemSetting/5153fb08c4c8fbd5af41d87e2ec38fbb.vehicle',
    ),
    351 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '76c021913e67d690f4b2967180482238',
      'native_key' => 'phpthumb_error_textcolor',
      'filename' => 'modSystemSetting/7c075c7626d1602e4eafbfbcf9ce8b58.vehicle',
    ),
    352 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'de4dc0d8b7902ce4b2dd41457c4d1b66',
      'native_key' => 'phpthumb_error_fontsize',
      'filename' => 'modSystemSetting/d3dc940b1c16855c28654780a084aeb2.vehicle',
    ),
    353 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '57ab804e7cc6d563dbc7e521946823c1',
      'native_key' => 'phpthumb_far',
      'filename' => 'modSystemSetting/1025d1fc9471b36e04ebcc2d8e41036e.vehicle',
    ),
    354 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f8c83b3a0fc34dbdac9214f6cbb9c271',
      'native_key' => 'phpthumb_imagemagick_path',
      'filename' => 'modSystemSetting/3fed2a7c4766d74c36a45c2e6aebc06e.vehicle',
    ),
    355 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'dcdaa8c69edc51de2410e09cf2cafd51',
      'native_key' => 'phpthumb_nohotlink_enabled',
      'filename' => 'modSystemSetting/8460ff625fae85715eb815d8ea93e548.vehicle',
    ),
    356 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fcdc040d89ad8fe0aff6a315b9c0a37d',
      'native_key' => 'phpthumb_nohotlink_erase_image',
      'filename' => 'modSystemSetting/caca4dbc86f771b1c2f32f6817c20fbe.vehicle',
    ),
    357 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e2af6a00b85ea9285cca32d9dccdd2ca',
      'native_key' => 'phpthumb_nohotlink_valid_domains',
      'filename' => 'modSystemSetting/6fb4c21ab5e87bd4daf02793d2ab404f.vehicle',
    ),
    358 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a2e17aa04c33bc65f332f47baafc7e3b',
      'native_key' => 'phpthumb_nohotlink_text_message',
      'filename' => 'modSystemSetting/d82f2500ca33df2c3f35dd97b200b541.vehicle',
    ),
    359 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '291f6cc7c960e2246dfafda6bcc51978',
      'native_key' => 'phpthumb_nooffsitelink_enabled',
      'filename' => 'modSystemSetting/5450b06910edc1d2077d6e3ff4504de3.vehicle',
    ),
    360 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c735032900e58235667385f0ef73abdf',
      'native_key' => 'phpthumb_nooffsitelink_erase_image',
      'filename' => 'modSystemSetting/0696e46d375995ac92655ac8256fa29a.vehicle',
    ),
    361 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8923ebc3712b436027a1dc32ba62c0b7',
      'native_key' => 'phpthumb_nooffsitelink_require_refer',
      'filename' => 'modSystemSetting/b0f65454d8d27f514e250799cf394e13.vehicle',
    ),
    362 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bf740fbf1a3f673f99780bef334043e9',
      'native_key' => 'phpthumb_nooffsitelink_text_message',
      'filename' => 'modSystemSetting/58945ae4557354cc8b7264a70db29efe.vehicle',
    ),
    363 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '424105522e462d615bd916f8e9cdca4c',
      'native_key' => 'phpthumb_nooffsitelink_valid_domains',
      'filename' => 'modSystemSetting/b61f01e7ec9ae4c3b9d9dd155ae6211d.vehicle',
    ),
    364 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7a8c4e9192f89fa9a9a3ea4feda76600',
      'native_key' => 'phpthumb_nooffsitelink_watermark_src',
      'filename' => 'modSystemSetting/5dfb4df584d138c35d72d7f6da1051b3.vehicle',
    ),
    365 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f2a6e0f95da0c07029a6fb9dc43b680d',
      'native_key' => 'phpthumb_zoomcrop',
      'filename' => 'modSystemSetting/799be4351e74015b0ccd7dc9bc60e348.vehicle',
    ),
    366 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3cd4e4568de7501c5641acc72afc0f93',
      'native_key' => 'publish_default',
      'filename' => 'modSystemSetting/8ec4cd6909029a527649da142d0b4804.vehicle',
    ),
    367 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '15e2f8bb05c2fd5293caedda4abf6882',
      'native_key' => 'rb_base_dir',
      'filename' => 'modSystemSetting/acba2e1b6cda7487d23d924b22e6bc8c.vehicle',
    ),
    368 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd99da4798040e2c2b6a2b237ddfa4bfa',
      'native_key' => 'rb_base_url',
      'filename' => 'modSystemSetting/3da22ab736507e657c8b2900ed8876a9.vehicle',
    ),
    369 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '133f35d394d2aa982a42892d50efd6ae',
      'native_key' => 'request_controller',
      'filename' => 'modSystemSetting/5f637e004c3eb664bdf2d4c7787d5113.vehicle',
    ),
    370 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2792a9b7c065522a1dc37a5dc71d2ef6',
      'native_key' => 'request_method_strict',
      'filename' => 'modSystemSetting/f1d334f89d31b2c8b05d7eedc11c923a.vehicle',
    ),
    371 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd85855486a62f447eb039a870ce38cd4',
      'native_key' => 'request_param_alias',
      'filename' => 'modSystemSetting/02051112036a8bf1da4d14ecb6b0a7e2.vehicle',
    ),
    372 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1f921dffc26b553a7504b368837d9cdb',
      'native_key' => 'request_param_id',
      'filename' => 'modSystemSetting/0a6554c86b90fd9a6089185c209bce0c.vehicle',
    ),
    373 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4ba3b1a1c937ece6317eea6fbc416c0a',
      'native_key' => 'resolve_hostnames',
      'filename' => 'modSystemSetting/8aaf896cf75d0dd5742a7ce763c385d8.vehicle',
    ),
    374 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '030642e115124075afebb172520ca9c0',
      'native_key' => 'resource_tree_node_name',
      'filename' => 'modSystemSetting/d8450b24b707245916edf5d824094848.vehicle',
    ),
    375 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ad5aa318bd0df6ed02f4837ecaebcc8f',
      'native_key' => 'resource_tree_node_name_fallback',
      'filename' => 'modSystemSetting/7ae656658b98ae5b09e6f5e12eb2a244.vehicle',
    ),
    376 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '15ec8f3c2c7e8e1f93506d67cdfeb726',
      'native_key' => 'resource_tree_node_tooltip',
      'filename' => 'modSystemSetting/41a5df117eb4d61406b4763c00ba7f7c.vehicle',
    ),
    377 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b6fe91fb08178799700f83f3cf8b1161',
      'native_key' => 'richtext_default',
      'filename' => 'modSystemSetting/c8ae4ec314c7b61c7193eb7c40d3b3c3.vehicle',
    ),
    378 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4cf84634ff44e27d011e417aae45974b',
      'native_key' => 'search_default',
      'filename' => 'modSystemSetting/197230712980c2c3a86d7d03cc305e9f.vehicle',
    ),
    379 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e1eab50c910b1d5bcdcb51928444dc4c',
      'native_key' => 'server_offset_time',
      'filename' => 'modSystemSetting/86e9fb22fe67da005775ddb1ef99b38f.vehicle',
    ),
    380 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f88e9bb6d6db09d4451af5a8819bdba5',
      'native_key' => 'server_protocol',
      'filename' => 'modSystemSetting/ab72963a7cdb88923fac31dc86abf085.vehicle',
    ),
    381 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c8e2510b06b2279f007cd0dd4b9c91a2',
      'native_key' => 'session_cookie_domain',
      'filename' => 'modSystemSetting/9529eb55c31ebca0bbe541562901cac8.vehicle',
    ),
    382 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6836872373196341d8a39121a655eae6',
      'native_key' => 'default_username',
      'filename' => 'modSystemSetting/a6098093bea6bce2ab3bdb588721d352.vehicle',
    ),
    383 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '50f6ce1a072a649490ae908bd29778e5',
      'native_key' => 'anonymous_sessions',
      'filename' => 'modSystemSetting/ce0738f279fba78403ab8102a3aff685.vehicle',
    ),
    384 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '286a34163a7a2b464bb29222482db19c',
      'native_key' => 'session_cookie_lifetime',
      'filename' => 'modSystemSetting/65516151e4a3c29774ba3d747346c346.vehicle',
    ),
    385 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2822f334b6a404792c599f1ec20711fa',
      'native_key' => 'session_cookie_path',
      'filename' => 'modSystemSetting/6b7b3623db68b5596b9ea4a9e32c95ae.vehicle',
    ),
    386 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e139cad6231a5649c7bba3dcdd7aafec',
      'native_key' => 'session_cookie_secure',
      'filename' => 'modSystemSetting/dd3d2be5714724bbd9aceec6c0408702.vehicle',
    ),
    387 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '70ceef97bde2a6ceea6d3a6b4da0cf7a',
      'native_key' => 'session_cookie_httponly',
      'filename' => 'modSystemSetting/505535edb5cac90195ed7313ca44b993.vehicle',
    ),
    388 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cfae150ef2a424539cd49ed70f29d2e5',
      'native_key' => 'session_gc_maxlifetime',
      'filename' => 'modSystemSetting/4330e611c304f3d0c2da0bbcb9a1b267.vehicle',
    ),
    389 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '23f7865fe45849e161471f55eeee626f',
      'native_key' => 'session_handler_class',
      'filename' => 'modSystemSetting/3dce0da52cadf33cd928d8e795ca99ed.vehicle',
    ),
    390 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '01d4b4861c60faf343c5e7f9d78f51fa',
      'native_key' => 'session_name',
      'filename' => 'modSystemSetting/5c8750ee8f51936182d07ee9da5212fa.vehicle',
    ),
    391 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0cacdca758b2b8affe0de49e461bcd82',
      'native_key' => 'set_header',
      'filename' => 'modSystemSetting/19ee311b3394ac606d2298cef3f2cffa.vehicle',
    ),
    392 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4e455ebfb70a48970a9ef3b4411d6203',
      'native_key' => 'send_poweredby_header',
      'filename' => 'modSystemSetting/3416ada7b4b13726783cfd06d04ce3f8.vehicle',
    ),
    393 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a5f2b3ec6ec2d0af733c409a41d4a62d',
      'native_key' => 'show_tv_categories_header',
      'filename' => 'modSystemSetting/fbb1a02eebd12dc4966afe6b042633e2.vehicle',
    ),
    394 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '372ab5973913586dd6a4c827ce71cc1f',
      'native_key' => 'signupemail_message',
      'filename' => 'modSystemSetting/0b10f01a2e1c2e0022d923b5bb7e78f6.vehicle',
    ),
    395 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '650ef33127a4d9216e1e2b72bd05dc33',
      'native_key' => 'site_name',
      'filename' => 'modSystemSetting/e9d848cc7e0f6cc66d16b9adf61ef434.vehicle',
    ),
    396 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8cf9d6ca380a3e59b99ffbcd4f02299c',
      'native_key' => 'site_start',
      'filename' => 'modSystemSetting/0132f8fe48063bbb72e5bc037807e469.vehicle',
    ),
    397 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6699bf37fab68b82300ed5a0a9113ed3',
      'native_key' => 'site_status',
      'filename' => 'modSystemSetting/167118fe81bb5c0a1309d966d5093cd3.vehicle',
    ),
    398 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4892ebaf8492b514c080421ac2dc4ea5',
      'native_key' => 'site_unavailable_message',
      'filename' => 'modSystemSetting/30b230f31c2328f0e94564bcde565793.vehicle',
    ),
    399 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '13918f78abd36b810bb033a0d0fb1b5a',
      'native_key' => 'site_unavailable_page',
      'filename' => 'modSystemSetting/18b62dee580f2e1834e467ccc7d98925.vehicle',
    ),
    400 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9aa175741adc678045c967535b99a72c',
      'native_key' => 'strip_image_paths',
      'filename' => 'modSystemSetting/8bf7cc7296cc7ec746938c3492c0ec4e.vehicle',
    ),
    401 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd294eceee5651849c397cc7b815547c2',
      'native_key' => 'symlink_merge_fields',
      'filename' => 'modSystemSetting/6d2e6e732c83feba9fe657d6124826d7.vehicle',
    ),
    402 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd11532aeefd92807b0151eed89c8ede3',
      'native_key' => 'syncsite_default',
      'filename' => 'modSystemSetting/e7526fcfd5efea04e629103848582e36.vehicle',
    ),
    403 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7ba446311b5b991bab3a25e78b4ba877',
      'native_key' => 'topmenu_show_descriptions',
      'filename' => 'modSystemSetting/bb32ecd29ee66d29bbe29863f00e6afe.vehicle',
    ),
    404 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ab53e76050c0af3d1b1c5594611aa893',
      'native_key' => 'tree_default_sort',
      'filename' => 'modSystemSetting/c861fc314ca92be2b3afb687ce88e249.vehicle',
    ),
    405 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '08e79bac131fe6790f7c643d31719dd6',
      'native_key' => 'tree_root_id',
      'filename' => 'modSystemSetting/74b0c0ba0951c4ac8f0748991ca5f092.vehicle',
    ),
    406 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '643d04d18abf841d480a9e8e4da28e01',
      'native_key' => 'tvs_below_content',
      'filename' => 'modSystemSetting/c588b264545cd8d75b7afc2a995ffad1.vehicle',
    ),
    407 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd246b2d031ad39b2376d4b3e40ab54c1',
      'native_key' => 'udperms_allowroot',
      'filename' => 'modSystemSetting/5be2247ed3008cfff63d49b925c92e44.vehicle',
    ),
    408 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5982e2371ff507e752e078d32fd1a073',
      'native_key' => 'unauthorized_page',
      'filename' => 'modSystemSetting/fc910faf56af6bbb6fba5539082e886b.vehicle',
    ),
    409 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8c210b262afc017788a4d4414d96d038',
      'native_key' => 'upload_files',
      'filename' => 'modSystemSetting/876a655666a2f8a3713d9dd0d1a4e21d.vehicle',
    ),
    410 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e0fc6d4a083291d68e2452e3fc6a9c26',
      'native_key' => 'upload_flash',
      'filename' => 'modSystemSetting/b78a7e8b70bd748c71c595622741d710.vehicle',
    ),
    411 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '59d3f69434a8972a3235c08d76ab45bc',
      'native_key' => 'upload_images',
      'filename' => 'modSystemSetting/e3a0051370e456128b6f69e7661a6dd8.vehicle',
    ),
    412 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'de527e9f310c95de01088639e1dd4d21',
      'native_key' => 'upload_maxsize',
      'filename' => 'modSystemSetting/f24d12368f3631d699018f2470407f87.vehicle',
    ),
    413 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '28073d6f5a5a11cd431e5c2612c0771b',
      'native_key' => 'upload_media',
      'filename' => 'modSystemSetting/04c56b63254423c891eaa834e3ad7ed0.vehicle',
    ),
    414 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '86336bd17a08ae253b08b8a77742ce6e',
      'native_key' => 'use_alias_path',
      'filename' => 'modSystemSetting/e4aa41c0bfdcae2e8ca2c19664f77bbd.vehicle',
    ),
    415 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '51468a08289c5f0a98a9ec0314a1cf5c',
      'native_key' => 'use_browser',
      'filename' => 'modSystemSetting/f9b7b505151fc0cf3ea4809cc35bf59a.vehicle',
    ),
    416 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cfd5ab2ed40fa5f8672e15522c931bf6',
      'native_key' => 'use_editor',
      'filename' => 'modSystemSetting/5a9febb0d07c454da63be73d30f8db5b.vehicle',
    ),
    417 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '02613caeff9a3eeb5579cd653894d5e0',
      'native_key' => 'use_multibyte',
      'filename' => 'modSystemSetting/4a30d0ec0736911c4104d1dbc020e777.vehicle',
    ),
    418 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4935052a80461d57adb4942b735be81b',
      'native_key' => 'use_weblink_target',
      'filename' => 'modSystemSetting/b2c02ebc4ef09e9242a312b0a69686eb.vehicle',
    ),
    419 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5b38e4b86ed5693217bb61f4a5f87b22',
      'native_key' => 'webpwdreminder_message',
      'filename' => 'modSystemSetting/a0ab936b1b4542a5231b99045f5447d2.vehicle',
    ),
    420 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '55412680c9bc601fd52795d2041fab35',
      'native_key' => 'websignupemail_message',
      'filename' => 'modSystemSetting/13ca67634df2b336a91e8c3400de356d.vehicle',
    ),
    421 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '24d2bf30d16b602ea998767f0a98bcd4',
      'native_key' => 'welcome_screen',
      'filename' => 'modSystemSetting/953b81c064301f7b7532f70d60dc020e.vehicle',
    ),
    422 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '095a90605dd8f0351a3f71ffc84fe09e',
      'native_key' => 'welcome_screen_url',
      'filename' => 'modSystemSetting/2389c2d8ed26965210defd77eb848ecf.vehicle',
    ),
    423 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b120ce59ad97350f314494b5a076d052',
      'native_key' => 'welcome_action',
      'filename' => 'modSystemSetting/80c080c58c43c5807d2d7f18ed2ade63.vehicle',
    ),
    424 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ed181a15d86bd67051580655a0fc6de5',
      'native_key' => 'welcome_namespace',
      'filename' => 'modSystemSetting/8f7838ef94efa69f17321999b48a3b6e.vehicle',
    ),
    425 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd10c042cbbf09408109372fffbc25812',
      'native_key' => 'which_editor',
      'filename' => 'modSystemSetting/7d63bebb8ddd4a3571da9b48b46b0ffa.vehicle',
    ),
    426 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8bb062e322650c30ceb7fcbb70e3aeda',
      'native_key' => 'which_element_editor',
      'filename' => 'modSystemSetting/15c22b6291c0f8f0c726e85de41b2e81.vehicle',
    ),
    427 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '63ca6ba1a8d74f7fa6f569f50e862ecb',
      'native_key' => 'xhtml_urls',
      'filename' => 'modSystemSetting/c5d532bf4551b39a1a19eb7c6a2b67c7.vehicle',
    ),
    428 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9d200795a6627a892d594a289690983c',
      'native_key' => 'enable_gravatar',
      'filename' => 'modSystemSetting/e9854132a9fad460ddef66493ba0e974.vehicle',
    ),
    429 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ac557ca2d986e95660d840a04314a2cf',
      'native_key' => 'mgr_tree_icon_context',
      'filename' => 'modSystemSetting/8ee43c8d45f54440a7d6342f6c5896d3.vehicle',
    ),
    430 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a7722b4fb0f261def900089b68aa19ea',
      'native_key' => 'mgr_source_icon',
      'filename' => 'modSystemSetting/304ee7f23c944e454191a3b89a8e77c5.vehicle',
    ),
    431 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ca8b5cbfd75d41ddd093c853eaf53c7d',
      'native_key' => 'main_nav_parent',
      'filename' => 'modSystemSetting/5132ace1d64238eaa14ff46014e60b67.vehicle',
    ),
    432 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '62ef681d073fc8d9be1c0f9edc7bba18',
      'native_key' => 'user_nav_parent',
      'filename' => 'modSystemSetting/38b98913814202476e87446ef4f98794.vehicle',
    ),
    433 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1a5476cc5094b2c43be6efd93dcfd97c',
      'native_key' => 'auto_isfolder',
      'filename' => 'modSystemSetting/1145d7b9b055ac8906dbc1bfe99cd1c4.vehicle',
    ),
    434 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6791d55c31f9f2c9423fae252c96eb02',
      'native_key' => 'manager_use_fullname',
      'filename' => 'modSystemSetting/03a1e8504def5b004a20137dd640cd49.vehicle',
    ),
    435 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f69bbb623a16f59dc92c810cdfca45c5',
      'native_key' => 'parser_recurse_uncacheable',
      'filename' => 'modSystemSetting/23a0c3da6b38729145767a5cb15f96fa.vehicle',
    ),
    436 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '168d034d6c690ce52b62f3fab39058e4',
      'native_key' => 'preserve_menuindex',
      'filename' => 'modSystemSetting/e01d18631ce209158fc8693e17845951.vehicle',
    ),
    437 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ada66aa4ca97565b134d990bcdf7bde9',
      'native_key' => 'allow_tv_eval',
      'filename' => 'modSystemSetting/d6de7d8b54c0a21ef2bf7517a51c88d0.vehicle',
    ),
    438 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e9aa689670a30de372ec1bb84b2d845a',
      'native_key' => 'log_snippet_not_found',
      'filename' => 'modSystemSetting/ecd888d41af292d79f05279c6cb73948.vehicle',
    ),
    439 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContextSetting',
      'guid' => 'd86ada2c20dae1f5d2d465658842cf53',
      'native_key' => 
      array (
        0 => 'mgr',
        1 => 'allow_tags_in_post',
      ),
      'filename' => 'modContextSetting/8f9fa0e2733141fac5ffa32e8bae5e65.vehicle',
    ),
    440 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContextSetting',
      'guid' => 'c6a066d669e6c4b2ac74deb25b9b1c08',
      'native_key' => 
      array (
        0 => 'mgr',
        1 => 'modRequest.class',
      ),
      'filename' => 'modContextSetting/8b9bda4d7b8dd8fbd56680a0beca12b7.vehicle',
    ),
    441 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modUserGroup',
      'guid' => '0f6d6987671afffc9bc91f10e432fa1c',
      'native_key' => 1,
      'filename' => 'modUserGroup/9a33954be16df8514b8b1747490936a2.vehicle',
    ),
    442 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboard',
      'guid' => '7023bd4e01a0ac2c27b13f2a0c8d7e89',
      'native_key' => 1,
      'filename' => 'modDashboard/bd1956ea48034348770757097ca029e6.vehicle',
    ),
    443 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMediaSource',
      'guid' => '2d4e89e980cd8f5abe977270b51c3ba8',
      'native_key' => 1,
      'filename' => 'modMediaSource/f787fe0c606a3b1d7f8b1b6b34df794d.vehicle',
    ),
    444 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => '31cf0c929fb7c6e5fc308225394f14fa',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/a39b0e82d4a172a223047cbca7114ca2.vehicle',
    ),
    445 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => '0433992c32c2c2c9b2bc7104bffede71',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/399dbc35d2d1454a00d202605089f0b5.vehicle',
    ),
    446 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => 'df0cc478e6a2146ca4ce2cc39b3ad3f7',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/bb4e5b1975a8be30175bc34c24066892.vehicle',
    ),
    447 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => '679aca4cdd34c6671d73d3d4b46b6f9d',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/95a4948d8f607b74e975812fcce04454.vehicle',
    ),
    448 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => 'e5a365892eb140eac102cd38abc6135d',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/49ab56a07370e6deda1b1ee8a38c2248.vehicle',
    ),
    449 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modUserGroupRole',
      'guid' => 'ed521f8b0e3a5c1204d933d6a8ce2368',
      'native_key' => 1,
      'filename' => 'modUserGroupRole/10a89bdfa9d893e53115fc7046a3debf.vehicle',
    ),
    450 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modUserGroupRole',
      'guid' => 'bbf9128ec976d89251d1ae388183e8b4',
      'native_key' => 2,
      'filename' => 'modUserGroupRole/afcdb0bb42cf6298668a84472e3f9cda.vehicle',
    ),
    451 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => '01fba35b4c6b89aed83231821860673f',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/3031fb1d70d283c9d1ce7c43d14fcdcd.vehicle',
    ),
    452 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => '4978e5fa0a328bfbf7e7e79d1090b228',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/375812d395b0c72d1dc169b4ca03045e.vehicle',
    ),
    453 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => 'dfa60b98ed1c4a09a18fa1bc230c11e1',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/e8794082b910a028cd28bea9029ff8bf.vehicle',
    ),
    454 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => '86dbca7052b6e23d6ae3a1223b1e6e4c',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/d1b5302138d2df9ef0549b944f740931.vehicle',
    ),
    455 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => '4f60e836fa81fdb48a5ea9115d8f1616',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/314b10d4f12fb90728d0821e0fb9d391.vehicle',
    ),
    456 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => '990b8adf392799b81f77450e1d8f52c9',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/b7398758b6e6b30cad573ed5c7dc754f.vehicle',
    ),
    457 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => '06cb2489146269e8d274cf600aff54e6',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/c091c90f397df47534cbbddee1d7ad29.vehicle',
    ),
    458 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => '333abcb3a93250548d867903a24fd2fa',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/435a4a3799c10b939e5f2eeaccf492b7.vehicle',
    ),
    459 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => 'dcfaa97089f4ea15f95370e73df3749e',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/6f2a46e8390aee47479c9a26458e2a4a.vehicle',
    ),
    460 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => 'a36e85adde8d2b6892ff58feb031d6d0',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/bfb63f44bd994270679b80893607663c.vehicle',
    ),
    461 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => 'b5ac11b947b50f6fe6df844cc5ff44b6',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/e265316c148ebe7c213fe60fed9d062a.vehicle',
    ),
    462 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => '6c23f5228559738092a9dc76c74ff969',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/58bb0e996481b0c997b5fe6273382761.vehicle',
    ),
    463 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => 'd2fafcc133075ed4a7430693d928938c',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/08d756f78c6f45b48ec46ae521f9ad73.vehicle',
    ),
    464 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '8def07b1883376395744cd63385bfa01',
      'native_key' => 1,
      'filename' => 'modAccessPolicy/b1a818756a21899472aa8ec5227987d7.vehicle',
    ),
    465 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '2f795f38ba4cb6a039671f1d95ca57b1',
      'native_key' => 2,
      'filename' => 'modAccessPolicy/ba1f0f3868de0b2c1373d9dd312f05b9.vehicle',
    ),
    466 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '1bcaef5147e0bb2d04e867f7949a7964',
      'native_key' => 3,
      'filename' => 'modAccessPolicy/f6591944eead54df52e78727c5af0111.vehicle',
    ),
    467 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'f09ec9e2f88a3a99ff03efc5f92935b7',
      'native_key' => 4,
      'filename' => 'modAccessPolicy/226046ae1ae03f4d36f71d427108bd2c.vehicle',
    ),
    468 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '4158ef9ee713eb5af5159c5abb33f0c3',
      'native_key' => 5,
      'filename' => 'modAccessPolicy/6845d2b73d5d96703fcd0d4652be660b.vehicle',
    ),
    469 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'f7d5c31158530849e9badbfdcbd8d5cf',
      'native_key' => 6,
      'filename' => 'modAccessPolicy/0c31290aff2a338831a16cce336c6f11.vehicle',
    ),
    470 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'a4fcce872b17819c507832d9c1bd1fc4',
      'native_key' => 7,
      'filename' => 'modAccessPolicy/e6cedf9a782476cba5d1c57c689b32f3.vehicle',
    ),
    471 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '9d7f4fa846e6b068740287ce5fb8d0ab',
      'native_key' => 8,
      'filename' => 'modAccessPolicy/435bafac61d9ee38fd774310b7391b4e.vehicle',
    ),
    472 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'ef786a7cdd85b7ee228cc67ab4980697',
      'native_key' => 9,
      'filename' => 'modAccessPolicy/1b2c6d51cd0223d354736b4c169d7f9d.vehicle',
    ),
    473 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '96d58aa36cfb6237674219ca6c4ebb0e',
      'native_key' => 10,
      'filename' => 'modAccessPolicy/870d42898e9fdd354c373f365a08cf77.vehicle',
    ),
    474 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '2e1a078ba1addbf490089e17006d9d65',
      'native_key' => 11,
      'filename' => 'modAccessPolicy/39224a0df0c55ba3f546061f8c205b75.vehicle',
    ),
    475 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '76a81134d05de39b9ecf4ed227a31f77',
      'native_key' => 12,
      'filename' => 'modAccessPolicy/0f5f72c6d4dd7b893ac2ab7568c1c9bf.vehicle',
    ),
    476 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContext',
      'guid' => '9607aedb0ea9414afa5a339fee8288ba',
      'native_key' => 'web',
      'filename' => 'modContext/9ab2ee02030c3a306dd0a0b15eef7240.vehicle',
    ),
    477 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContext',
      'guid' => '930d39b3340971ac91d1119ce43d8fa2',
      'native_key' => 'mgr',
      'filename' => 'modContext/3308d2675cbf6976c68e5dcafb87e017.vehicle',
    ),
    478 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => 'bb3cbd76900a0426abff3d7dcd855710',
      'native_key' => 'bb3cbd76900a0426abff3d7dcd855710',
      'filename' => 'xPDOFileVehicle/a5c414b4d541a40da7789a60d1d0e93e.vehicle',
    ),
    479 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '0625035cf3d8829e748650f9beb70bc9',
      'native_key' => '0625035cf3d8829e748650f9beb70bc9',
      'filename' => 'xPDOFileVehicle/c3bbb54cc9f1dca7940e43ebb678acbb.vehicle',
    ),
    480 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => 'fc6cf979060aea5f7c4d8fbe44ee1677',
      'native_key' => 'fc6cf979060aea5f7c4d8fbe44ee1677',
      'filename' => 'xPDOFileVehicle/40b6aa86adea961cd87cc7adcc4b0296.vehicle',
    ),
    481 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '9d3bcb4f3966481bee01577938004b6b',
      'native_key' => '9d3bcb4f3966481bee01577938004b6b',
      'filename' => 'xPDOFileVehicle/acb2475a755a6a1eba6e8594e0df562e.vehicle',
    ),
  ),
);